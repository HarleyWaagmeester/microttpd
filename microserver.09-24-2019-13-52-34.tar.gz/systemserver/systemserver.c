/** Feel free to use this example code in any way
*   you see fit (Public Domain)
 **/

/** A very simple webserver using the GNU libmicrohttpd library.
 * The url is interpreted either as a file pathname or a process to be started.
 **/

#include <syslog.h>
#include <sys/types.h>
#ifndef _WIN32
#include <sys/select.h>
#include <sys/socket.h>
#else
#include <winsock2.h>
#endif
#include <microhttpd.h>
#include <time.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <errno.h>
#include <strings.h>
#include <ctype.h>
#include <linux/limits.h>
#include <errno.h>

#define PORT 1338
#define HTML_MIMETYPE "text/html"
#define CSS_MIMETYPE "text/css"
#define JS_MIMETYPE "text/javascript"
#define PNG_MIMETYPE "image/png"
#define MAX_TEXT_SIZE 100000
#define MAX_SOURCE_SIZE (0x100000)

// This code is not thread safe.
static struct stat sbuf;
static int fd_error_ret;

// Prototypes ---------------------------------------------------------------
char * searchReplace(char * string, char *toRep, char *rep);
// -------------------------------------------------------------------------

// Utilities ----------------------------------------------------------------
static int
print_out_key (void *cls, enum MHD_ValueKind kind, 
	       const char *key, const char *value)
{
  //printf ("%s: %s\n", key, value);
  return MHD_YES;
}


// Convert a string to lowercase.
// This overwrites the referenced string.
char* strlwr(char* s) {
  for (;*s;++s) {
    *s = tolower((unsigned char) *s);
  }
  
  return 0;
}

static int
execute_read_pipe (char* program, struct MHD_Connection *connection) {
  struct MHD_Response *response;
  FILE *fpipe;
  int data_length;
  char data[MAX_TEXT_SIZE]; // This will truncate very large responses. Dynamic buffer allocation isn't implemented.
  int ret;
  
  if ( !(fpipe = (FILE*)popen(program,"r")) )
      {  // If fpipe is NULL
        syslog(LOG_CRIT,"%s","Problem with pipe");
        perror("Problems with pipe");
        exit(1);
      }

    data_length = fread(data, 1, MAX_TEXT_SIZE-1, fpipe);
    data[data_length+1] = 0;
    if (MAX_TEXT_SIZE-1 == data_length ) {
      exit(0);
    }
    pclose(fpipe);
    response = MHD_create_response_from_buffer (strlen (data),
						(void*) data, MHD_RESPMEM_MUST_COPY);
    ret = MHD_queue_response (connection, MHD_HTTP_OK, response);
    return ret;
  }

static int
write_to_css_file(char* url) {
  int fd = 0;
  char* pathname;
  pathname = malloc(PATH_MAX);
  strcpy(pathname, "/home/nsa/GIT/mhttpd/files/");
  strcat(pathname, "write_to_css_file.css");
   
  if ( (-1 == (fd = open (pathname, O_CREAT|O_WRONLY,S_IRWXU))) ||
       (0 != fstat (fd, &sbuf)) )
    {
       
      /* handle error accessing file */
      syslog(LOG_CRIT,"open errno is %s (errno=%d)\n", strerror( errno ), errno );
      if (fd != -1)
        (void) close (fd);
      return -1;
    }
  strcat(url,"\n");
  if ( -1 == write(fd,url,strlen(url))) {
    syslog(LOG_CRIT,"write errno is that %x %s (errno=%d)\n", fd,strerror( errno ), errno );
    (void) close (fd);
    return -1;
  }
  (void) close (fd);
  return 0;
}
// --------------------------------------------------------------------------

// Look for the file specified in the url.
// Return a file descriptor on success.
// If the file or isn't found create an error response and set the global variable fd_error_ret to the MHD_queue_response of the error response. 
static int
resolve_url (const char* filename, struct MHD_Connection *connection) {

  struct MHD_Response *response;
  int fd = 0 ;
  unsigned int ret;
  //struct stat sbuf;
  char* pathname;
  const char* ROOT = "/home/nsa/GIT/mhttpd";
  
  pathname = malloc(PATH_MAX);

  // server root directory
  syslog(LOG_CRIT,"ROOT: %s",ROOT);
  snprintf(pathname,PATH_MAX,"%s%s",ROOT, filename);
  syslog(LOG_CRIT,"pathname: %s",pathname);

  if ( (-1 == (fd = open (pathname, O_RDONLY))) ||
       (0 != fstat (fd, &sbuf)) )
    {
        
      /* handle error accessing file */
      //syslog(LOG_CRIT,"errno is %s (errno=%d)\n", strerror( errno ), errno );
      if (fd != -1)
      	(void) close (fd);
      const char *errorstr =
        "<html><body>page not found:: subtext: file access error\
                              </body></html>";
      response =
      	MHD_create_response_from_buffer (strlen (errorstr),
      					 (void *) errorstr,
      					 MHD_RESPMEM_PERSISTENT);
      if (NULL != response)
        {
	  fd_error_ret =
	    MHD_queue_response (connection, MHD_HTTP_NOT_FOUND,
				response);
	  MHD_destroy_response (response);

	  return -1;
        }else {
        return MHD_NO;
      }
    }
  return fd;
}


int 
create_response (int fd, char* mime_type, struct MHD_Connection *connection) 
{
  struct MHD_Response *response;
  int ret;
  response =
    MHD_create_response_from_fd_at_offset64 (sbuf.st_size, fd, 0);
  MHD_add_response_header (response, "Content-Type", mime_type);
  ret = MHD_queue_response (connection, MHD_HTTP_OK, response);
  MHD_destroy_response (response);
  return ret;
}


static int
router (void *cls, struct MHD_Connection *connection,
                      const char *url_, const char *method,
                      const char *version, const char *upload_data,
                      size_t *upload_data_size, void **con_cls)
{
  struct MHD_Response *response;
  int fd = 0 ;
  int ret;
  char* url;
  //struct stat sbuf;
  FILE *fpipe;
  char data[MAX_TEXT_SIZE]; // This will limit the text size.
  int data_length;
  char syslog_message[1024];
  
  sprintf (syslog_message, "New %s request for %s using version %s\n", method, url_, version);
  syslog(LOG_CRIT, "%s", syslog_message);
  
  MHD_get_connection_values (connection, MHD_HEADER_KIND, &print_out_key, NULL);
  if (0 != strcmp (method, "GET"))
    return MHD_NO;

  // copy const url_ to a variable
  url = malloc(strlen(url_)+1);
  char* result;
  strcpy(url,url_);
  url[strlen(url_)+1]=0;
  // convert url to lowercase
  //syslog(LOG_CRIT,"before strlwr");
  //  strlwr(url);
  //syslog(LOG_CRIT,"after strlwr");


  if (0 == (strncmp(url,"/formatted_write_to_css_file/",19))) {
    syslog(LOG_CRIT,"formatted_write_to_css_file is matched");
    result = (searchReplace(url,"/write_to_css_file/",""));
    result = (searchReplace(result,"{","{\n"));
    result = (searchReplace(result,";",";\n"));
    result = (searchReplace(result,"}","}\n"));
    write_to_css_file(result);
    return 0;
  }

  
  //////////////////////////////////
  //url == /favicon.ico
  //////////////////////////////////

  if (0 == (strncmp(url,"/favicon.ico",12))) {
    //syslog(LOG_CRIT"matched /favicon.ico");
    fd = resolve_url("/images/favicon.ico",connection);
    if (-1 == fd) {
      return fd_error_ret;
    }else {
      ret = create_response(fd, PNG_MIMETYPE, connection);
      //close(fd);
      return ret;
    }
  }

  ///////////////////////////////////
  // url == /images/
  //////////////////////////////////
  
  if (0 == (strncmp(url,"/images/",8))) {
    fd = resolve_url(url,connection);
    if (-1 == fd) {
      return fd_error_ret;
    }else {
      ret = create_response(fd, PNG_MIMETYPE, connection);
      return ret;
    }
  }

  ///////////////////////////////////
  // url == /html/
  ///////////////////////////////////

  if (0 == (strncmp(url,"/html/",6))) {
    if (-1 == (fd = resolve_url(url, connection))) {
      return fd_error_ret;
    }else {
      ret = create_response(fd, HTML_MIMETYPE, connection);
      return ret;
    }
  }

  ///////////////////////////////////
  // url == /files/
  ///////////////////////////////////

  if (0 == (strncmp(url,"/files/",7))) {
    syslog(LOG_CRIT,"/files/ is matched");
    if (-1 == (fd = resolve_url(url, connection))) {
      return fd_error_ret;
    }else {
      ret = create_response(fd, HTML_MIMETYPE, connection);
      return ret;
    }
  }

  /////////////////////////////////////
  // url == /css/
  /////////////////////////////////////
  
  if (0 == (strncmp(url,"/css/",5))) {
    if (-1 == (fd = resolve_url(url, connection))) {
      return fd_error_ret;
    }else {
      ret = create_response(fd, CSS_MIMETYPE, connection);
      return ret;
    }
  }
  ////////////////////////////////////////
  // url == /js/
  ////////////////////////////////////////
  
  if (0 == (strncmp(url,"/js/",4))) {
    if (-1 == (fd = resolve_url(url, connection))) {
      syslog(LOG_CRIT,"%s", "in /js/ resolve_url failed");
      return fd_error_ret;
    }else {
      ret = create_response(fd, JS_MIMETYPE, connection);
      return ret;
    }
  }

  ////////////////////////////////////
  // url == /colorpicker-master/
  /////////////////////////////////////
  
  if (0 == (strncmp(url,"/colorPicker-master/",20))) {
    if (-1 == (fd = resolve_url(url, connection))) {
      return fd_error_ret;
    }else {
      ret = create_response(fd, HTML_MIMETYPE, connection);
      return ret;
    }
  }

  //This is a cludge because subdirectory descent isn't implemented. */
  //////////////////////////////////////
  // url == /colorpicker-master/css
  /////////////////////////////////////
  
  if (0 == (strncmp(url,"/colorPicker-master/css/",24))) {
    //printf("matched /colorPicker-master/css/\n");
    if (-1 == (fd = resolve_url(url, connection))) {
      return fd_error_ret;
    }else {
      ret = create_response(fd, CSS_MIMETYPE, connection);
      return ret;
    }
  }

  ////////////////////////////////////////////
  // url == /psauxf/
  ////////////////////////////////////////////
  
  if (0 == (strncmp(url,"/psauxf",7))) {
    return  execute_read_pipe("ps auxf",connection);
  }

  ////////////////////////////////////////////
  // url == /pstree/
  ////////////////////////////////////////////

  if (0 == (strncmp(url,"/pstree",7))) {
    return  execute_read_pipe("pstree -acl",connection);
  }

  //////////////////////////////////////
  //url == /xterm-mhttpd
  ///////////////////////////////////////
  
  if (0 == (strncmp(url,"/xterm-mhttpd",13))) {

    int pid = fork();
    //    pid = -1;

    if (pid == 0) {
      // Exec
      char* const argv[] = {"/usr/bin/xterm", "-fn", "9x15", NULL};
      char* const envp[] = {"DISPLAY=:0.0", "HOME=/home/nsa", NULL};
      chdir("/home/nsa/GIT/mhttpd");
      execve("/usr/bin/xterm", argv, envp);
    } else if (pid == -1) {
      //printf("fork() failed!");
    } else {
      // This is the parent process
      //printf("I'm the parent process, pid=%d\n", getpid());
      //
    }
    // Show a message in the browser.
    const char *page  = "<html><body>\"/usr/bin/xterm\", \"-fn\", \"9x15\"<br></body></html>";
    response = MHD_create_response_from_buffer (strlen (page),
						(void*) page, MHD_RESPMEM_PERSISTENT);
    ret = MHD_queue_response (connection, MHD_HTTP_NOT_FOUND, response);
    return ret;
  }

  //////////////////////////////////////
  //url == /runScript_movePageCreatorFiles
  ///////////////////////////////////////
  
  if (0 == (strncmp(url,"/runscript_movepagecreatorfiles",31))) {
    syslog(LOG_CRIT,"/runscript_movepagecreatorfiles is matched");
    //  fd = resolve_url("/html/xterm_png.html", connection);
    //  ret = create_response(fd, HTML_MIMETYPE, connection);

    int pid = fork();
    //    pid = -1;

    if (pid == 0) {
      // Exec
      syslog(LOG_CRIT,"%s","I'm the child process");
    
      // Exec
      char* const argv[] = {"-c", "/home/nsa/bin/movePageCreatorFiles", NULL};
      char* const envp[] = {"DISPLAY=:0.0", "HOME=/home/nsa", NULL};
      chdir("/home/nsa/GIT/mhttpd");
      execve("/bin/bash", argv, envp);
    } else if (pid == -1) {
      //printf("fork() failed!");
    } else {
      // This is the parent process
      //printf("I'm the parent process, pid=%d\n", getpid());
      //
    }
    // Show a message in the browser.
    const char *page  = "<html><body>movePageCreatorFiles<br></body></html>";
    response = MHD_create_response_from_buffer (strlen (page),
						(void*) page, MHD_RESPMEM_PERSISTENT);
    ret = MHD_queue_response (connection, MHD_HTTP_NOT_FOUND, response);
    return ret;
  }
  
  /////////////////////////////////////
  //url == /xfce4-terminal-in-mhttpd
  /////////////////////////////////////
  
  if (0 == (strncmp(url,"/xfce4-terminal-in-mhttpd",25))) {

    int pid = fork();
    //    pid = -1;

    if (pid == 0) {
      // Exec
      char* const argv[] = {"/usr/bin/xfce4-terminal",\
                            "-e ",\
                            "bash -c 'emacs26 -mm js/diver.js &\
                             bash'",\
                            NULL};
      chdir("/home/nsa/GIT/mhttpd");
      execv("/usr/bin/xfce4-terminal", argv);
    } else if (pid == -1) {
      //syslog(LOG_CRIT,"fork() failed!");
    } else {
      // This is the parent process
      //printf("I'm the parent process, pid=%d\n", getpid());
      //
    }
    // Show a message in the browser.
    const char *page  = "<html><body>\"/usr/bin/xfce4-terminal\"<br></body></html>";
    response = MHD_create_response_from_buffer (strlen (page),
						(void*) page, MHD_RESPMEM_PERSISTENT);
    ret = MHD_queue_response (connection, MHD_HTTP_NOT_FOUND, response);
    return ret;
  }

  /////////////////////////////////////
  //url == menu.bin
  /////////////////////////////////////
  
  if (0 == (strncmp(url,"/exec/menu.bin",14))) {

    int pid = fork();

    if (pid == 0) {
      chdir("/home/nsa/GIT/mhttpd/exec");
      char* const argv[] = {NULL};
      //      execve("/usr/bin/xterm", argv, envp);
      execv("/home/nsa/GIT/mhttpd/exec/menu.bin", argv);
    } else if (pid == -1) {
      //syslog(LOG_CRIT,"fork() failed!");
    } else {
      // This is the parent process
      //printf("I'm the parent process, pid=%d\n", getpid());
      //
    }
    // Show a message in the browser.
    const char *page  = "<html><body>\"menu.bin\"<br></body></html>";
    response = MHD_create_response_from_buffer (strlen (page),
						(void*) page, MHD_RESPMEM_PERSISTENT);
    ret = MHD_queue_response (connection, MHD_HTTP_NOT_FOUND, response);
    return ret;
  }
  /////////////////////////////////////
  //url == pipe.bin
  /////////////////////////////////////
  
  if (0 == (strncmp(url,"/exec/pipe.bin",13))) {

    int pid = fork();

    if (pid == 0) {
      chdir("/home/nsa/GIT/mhttpd/exec");
      char* const argv[] = {NULL};
      //      execve("/usr/bin/xterm", argv, envp);
      execv("/home/nsa/GIT/mhttpd/exec/pipe.bin", argv);
    } else if (pid == -1) {
      //syslog(LOG_CRIT,"fork() failed!");
    } else {
      // This is the parent process
      //printf("I'm the parent process, pid=%d\n", getpid());
      //
    }
    // Show a message in the browser.
    const char *page  = "<html><body>\"pipe.bin\"<br></body></html>";
    response = MHD_create_response_from_buffer (strlen (page),
						(void*) page, MHD_RESPMEM_PERSISTENT);
    ret = MHD_queue_response (connection, MHD_HTTP_NOT_FOUND, response);
    return ret;
  }

  // no match found
  const char *page  = "<html><body>page not found:: subtext: default error<br></body></html>";
  response = MHD_create_response_from_buffer (strlen (page),
					      (void*) page, MHD_RESPMEM_PERSISTENT);
  ret = MHD_queue_response (connection, MHD_HTTP_NOT_FOUND, response);
  return ret;
}


int
main ()
{
  char s [1024];
  char version [] = "000x1";
  int daemon_result;
  int errsv;
  struct MHD_Daemon *d;

  openlog("systemserver",LOG_PID|LOG_CONS,LOG_DAEMON);
  daemon_result = daemon(1,0); 
  errsv = errno;
  if ( 0 == daemon_result) {
      syslog(LOG_CRIT, "systemserver says: daemon(1,0) returned success");
    } else {
    syslog(LOG_CRIT, "systemserver says: daemon(1,0) failed");
    sprintf(s,"%x",errsv);
    syslog(LOG_CRIT, "%s",s);      
    }
  syslog(LOG_CRIT, "systemserver %s is in operation\n",version);

    // libmicrohttpd needs to start after the host program is daemonized.
    d = MHD_start_daemon (MHD_USE_SELECT_INTERNALLY, PORT, NULL, NULL,
                          &router, NULL, MHD_OPTION_END);
    if (NULL == d) {
      syslog(LOG_CRIT, "error starting systemserver libmicrohttpd daemon");
      return 1;
    }

    
    while (1) {sleep (5);};
    MHD_stop_daemon (d);
    return 0;
}
