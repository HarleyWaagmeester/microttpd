/**
 * Feel free to use this example code in any way
 * you see fit (Public Domain)

 * Part of a very simple webserver using the GNU libmicrohttpd library.

 * Utilities to create files and operate upon files with the searchReplace function.

 **/

// cc -Wall utilSearchReplace.c searchReplace.c

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <fcntl.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#define MAX_SOURCE_SIZE (0x100000)

char * searchReplace(char * string, char *toRep, char *rep);
int openFile(char* pathname);
int usage();

char*  prog;

int
main(int argc, char* argv[]) {
  int in = -1;
  int out = -1;
  char* buf;
  char* bufStart;
  int nr;
  char* prog = argv[0]; 


  char* c = argv[3];
  int n = atoi (argv[4]);
  char* s_term = argv[3];
  char* r_term = argv[4];
  char* result;

  buf = bufStart = malloc(MAX_SOURCE_SIZE);

  if(argc == 1) {
    usage();
  }

  ///////////////////////////////
  // Replace
  ///////////////////////////////
  
  if (0 == (strcmp(argv[1],"replace"))) {
    
    if (argc != 6) {
      usage();
    }

    char* inPathname = argv[2];
    char* outPathname = argv[5];

    if(-1 == (in = openFile(inPathname))) {
      exit(1);
    }
    if(-1 == (out = openFile(outPathname))) {
      exit(1);
    }

    while ((MAX_SOURCE_SIZE > (nr = read(in,buf,1000))) && (nr != 0)) {
      buf+=1000;
      if ( -1 == nr) {
        fprintf(stderr,"%s\n",strerror(errno));
        exit(1);
      }
      //          fprintf(stderr,"%x, %d\n",buf,nr);
    }

    //        fprintf(stderr,"pre\n%s\n",buf);
    (void) close (in);

    result = searchReplace(bufStart,s_term,r_term);
    buf[nr+1]=0;
    //        fprintf(stderr,"post\n%s\n%s\n",buf,result);
    if ( -1 == write(out,result,strlen(bufStart))) {
      fprintf(stderr,"write errno is %s (errno=%d)\n", strerror( errno ), errno );
      (void) close (out);
      return -1;
    }
    return 0;
  }
  //        fprintf(stdout,"%s",result);


  //////////////////////////////
  // Create
  /////////////////////////////
  
  if (0 == (strcmp(argv[1],"create"))) {
 
    if (argc != 5) {
      usage();
      exit (1);
    }

    char* filePathname = argv[2];

    printf("%s\n",filePathname);
    if(-1 == (out = openFile(filePathname))) {
      exit(1);
    }
    while(n--) {
      if ( -1 == write(out,c,1)) {
        fprintf(stderr,"%s: write errno is: %x %s (errno=%d)\n",prog, out,strerror( errno ), errno );
        (void) close (out);
        return -1;
      }
    }
    (void) close (out);
    return (0);
  }
}

int
openFile(char* pathname) {
  struct stat sbuf;
  int fd = 0;
  
  if ( (-1 == (fd = open (pathname, O_CREAT|O_RDWR,S_IRWXU))) ||
       (0 != fstat (fd, &sbuf)) )
    {
      /* handle error accessing file */
      fprintf(stderr,"open errno is %s (errno=%d)\n", strerror( errno ), errno );
      if (fd != -1)
        (void) close (fd);
      return -1;
    }
  return fd;
}

int
usage() {
  fprintf(stderr,"usage: %s\ncreate <filename> <ascii_character_to_write> <count>\
                                \nreplace <input_filename> <ascii_string_to_replace> <replacement_string> <output_filename>\n",\
          prog);
  exit (1);
}
