#include <syslog.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>



int
main() {
  syslog(LOG_CRIT,"%s","RUNNING: runScript_movePageCreatorFiles");
  system("/home/nsa/bin/movePageCreatorFiles");
  syslog(LOG_CRIT,"%s","FUNISHED: runScript_movePageCreatorFiles");
  fprintf(stdout,"finished\n");
}
