
// This is in development to look for enclosing html tags and extract those enclosing tags and the contents.
// cc -Wall -g extract.c -o extract

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define BUFSIZE_M 1024

char *r;
char *s;

int search_and_copy (char* search_term, int block_ptr);

int main(int argc, char *argv[]){
  char open_tag[1024];
  char close_tag[1024];
  char filename[1024];
  
  if (argc != 4){
    printf("usage %s: <opening tag> <closing tag> <filename>\n",argv[0]);
    exit(1);
  }

  strncpy(open_tag,argv[1],BUFSIZE_M);
  strncpy(close_tag,argv[2],BUFSIZE_M);
  strncpy(filename,argv[3],BUFSIZE_M);

  FILE *f = fopen(filename, "rb");
  if (NULL == f) {
    perror("opening aaa");
    return 1;
  }
  fseek(f, 0, SEEK_END);
  long fsize = ftell(f);
  fseek(f, 0, SEEK_SET);  /* same as rewind(f); */

  s = malloc(fsize + 1);
  r = malloc(fsize + 1);
  fread(s, 1, fsize, f);
  fclose(f);

  s[fsize] = 0;


  // Use the search term size to sequence blocks of text from the source string.
  int z=0;
  for(z=0;s[z]!=0;z++) { //// block sequence
  /* for(z=0;z<strlen(s)+1;z=z+strlen(open_tag)+1) { //// block sequence */
    search_and_copy(open_tag,z);
  }//// end of block sequence
  return 0;
}

int
search_and_copy (char* search_term, int block_ptr) {
  int i=0;
  int j=0;

  //  int success = 0;
  int matched_first_char = 0;

  // Search for the first matching character and then then continue until a non matching character  or a complete match is found while copying
  // the matched characters into the result character array.

  for (i=block_ptr;i<block_ptr+strlen(search_term)+1;i++) {
    //printf("block_ptr=%x, s[%x]=%c, search_term[%x]=%c, r[%x]=%c\n",block_ptr,i,s[i],j,search_term[j],j,r[j-1]);
    for (int a = block_ptr; a<block_ptr+strlen(search_term)+1; a++) {
      putchar(s[a]);
        }   
    putchar('\n');
    if ( (tolower(s[i]) != search_term[j]) && (matched_first_char == 1) ) {
      matched_first_char = 0;
      j = 0;
      continue;
    }
    if (tolower(s[i]) != search_term[j]) {
      continue;
    }else {
      matched_first_char = 1;
      r[j++] = s[i];
      r[j] = 0;
      if (j == strlen(search_term)) {
        printf("matched: %s\n",r);
        //          success = 1;
        j = 0;
        break;
      }
    }
  }
  return 0;
}
