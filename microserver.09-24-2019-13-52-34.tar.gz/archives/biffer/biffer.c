//Project biffer.c -----------------------------------


/* This is a snapshot of the developement code. */
/* This a very low profile project being used to investigate classic process control */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <syslog.h>
#include <pwd.h>
#include <signal.h>
#include <biff.h>
#include <sys/poll.h>
#include <errno.h>

//#define DAEMON
#define BS 255
#define IS 1024
//#define DELAY 60
extern errno;
struct biff
{

  int x;
  struct stat st;
  char *n;
  char mp3[BS];
  char logfile_name[BS];
  char logfile_arg[BS];
  char mailfile_arg[BS];
  char input[BS];
  char buf[BS];
  int fifo;
  int mailfile;
  int logfile;
  time_t stored_mtime;
  char fstat_info[IS];
  int fstat_info_size;
  time_t time_value;
  char *ctime_string;
  struct passwd *pwd;
  uid_t uid;
  struct pollfd *fds;
  int fdcount;
  int rv;
  int loop;
  int i;
  int delay;

  sigset_t sigmask;
  sigset_t orig_sigmask;
  fd_set rd;
  struct timeval tv;
  int retval;
};


struct biff *p;

int close_all_files(void)
{
  if (p->logfile) close(p->logfile);
  if (p->mailfile) close(p->mailfile);
  closelog();
  return(0);
}


int set_file_check_alarm()
{
  signal(SIGALRM,check_files);
  alarm(p->delay);
  return(0);
}

int syslog_(char *string,int error_number)
{
  char text[BS];
  snprintf(text,BS,"%s %s",string,strerror(error_number));
  syslog(LOG_USER|LOG_INFO,text);
  raise(SIGTERM);
  return(0);
}

sighandler_t check_files()
{
  /*
     if ( (logfile=open(logfile_arg,O_RDWR|O_CREAT|O_APPEND,S_IRWXU)) == -1)
     {
     syslog_("can't open logfile",errno);
     raise(SIGTERM);
     }
     if ( (mailfile=open(mailfile_arg,O_RDONLY)) == -1)
     {
     syslog_("can't open the mail spool file",errno);
     raise(SIGTERM);
     }
     */
  if(fstat(p->mailfile, &p->st) == -1)
  {
    syslog_("Could not stat the mail spool file",errno);
    raise(SIGTERM);
  }
  if (p->stored_mtime != p->st.st_mtime)
  {
    p->stored_mtime = p->st.st_mtime;
    system(p->mp3);
  }
  p->time_value = time(NULL);
  p->ctime_string = (char *)ctime(&p->time_value);
  snprintf(p->fstat_info,IS,"\nBEGIN %s\nst.st_size = %u\nst.atime = %0x\nst.mtime = %0x\nEND\n",p->ctime_string,p->st.st_size,p->st.st_atime,p->st.st_mtime);
  if ( write(p->logfile,p->fstat_info, strlen(p->fstat_info)) == -1 )
  {
    syslog_("could not write to logfile",errno);
    raise(SIGTERM);
  }
  //  if (logfile) close(logfile);
  //  if (mailfile) close(mailfile);
  set_file_check_alarm();
  return(0);
}/*check_files*/

sighandler_t signal_handler(int sig)
{
  if ( sig == SIGTERM )
  {
    close_all_files();
    syslog(LOG_USER|LOG_INFO,"caught SIGTERM, this process is terminating");
    exit(SIGTERM);
  }
  return(0);
}

int read_input(fd)
{
  syslog(LOG_USER|LOG_INFO,"in read_input");
  while ( read(fd,p->input,BS) );
  syslog(LOG_USER|LOG_INFO,p->input);
  close(p->fifo);
  if ( (p->fifo=open("/home/mike/BIFFER_FIFO",O_RDONLY|O_NDELAY)) == -1 )
  {
    syslog_("error opening /home/mike/BIFFER_FIFO",errno);
    raise(SIGTERM);
    return(0);
  }

  syslog(LOG_USER|LOG_INFO,"leaving read_input");
  return(0);
}


/* main */
int main (int argc, char**argv)
{

  if (argc < 5)
  {
    printf("usage: biffer [/var/mail/username] [file.mp3] [logfile] [delay]\n");
    exit(0);
  }
  p = calloc( sizeof(struct biff),1 );
  p->fstat_info_size = IS;
  p->fdcount = 3;
  p->loop = 1;
  strncpy(p->logfile_arg,argv[3],BS);
  strncpy(p->mailfile_arg,argv[1],BS);
  p->delay = atoi(argv[4]);
#ifdef DAEMON

  if ( (daemon(0,0)) == -1 )
  {
    perror("cannot daemonize: ");
    exit(SIGTERM);
  }
#endif

  signal(SIGTERM,signal_handler);
  p->uid = getuid();
  p->pwd = getpwuid(p->uid);
  snprintf(p->logfile_name,BS,"biffer(%s,%d)",p->pwd->pw_name,p->pwd->pw_uid);
  snprintf(p->mp3,BS,"mpg123 %s",argv[2]);
  openlog(p->logfile_name,LOG_PID,LOG_USER);
  syslog(LOG_USER|LOG_INFO,p->logfile_name);
  if ( mkfifo("/home/mike/BIFFER_FIFO",777) != 0 )
  {
    if ( errno != EEXIST )
    {
      syslog_("mkfifo(..) error: ",errno);
      raise(SIGTERM);
    }
  }
  if ( (p->fifo=open("/home/mike/BIFFER_FIFO",O_RDONLY|O_NDELAY)) == -1 )
  {
    syslog_("error opening /home/mike/BIFFER_FIFO",errno);
    raise(SIGTERM);
  }
  if ( (p->mailfile=open(p->mailfile_arg,O_RDONLY)) == -1)
  {
    syslog_("can't open the mail spool file",errno);
    raise(SIGTERM);
  }
  if ( (p->logfile=open(p->logfile_arg,O_RDWR|O_CREAT|O_APPEND,S_IRWXU)) == -1)
  {
    syslog_("can't open logfile",errno);
    raise(SIGTERM);
  }
  sigemptyset (&p->sigmask);
  sigaddset (&p->sigmask,SIGALRM);
  //  sigprocmask(SIG_BLOCK,&sigmask,&orig_sigmask);
  set_file_check_alarm();

  while(1)
  {
    FD_ZERO(&p->rd);
    FD_SET(p->fifo,&p->rd);
    p->tv.tv_sec = 1;
    p->tv.tv_usec = 0;
    if ( sigprocmask(SIG_BLOCK,&p->sigmask,&p->orig_sigmask) == -1 )
    {
      syslog_("sigprocmask - SIG_BLOCK: ",errno);
      raise(SIGTERM);
    }
    p->retval = select(p->fifo+1,&p->rd,NULL,NULL,&p->tv);
    if ( sigprocmask(SIG_UNBLOCK,&p->sigmask,NULL) == -1 )
    {
      syslog_("sigprocmask - SIG_UNBLOCK: ",errno);
      raise(SIGTERM);
    }
    //    if (retval == -1 && errno == EINTR)
    //      continue;
    if (p->retval < 0)
    {
      syslog_("select error",errno);
      raise(SIGTERM);
    }

    if ( p->retval )
    {
      if ( FD_ISSET(p->fifo,&p->rd) )
      {
        read_input(p->fifo);
      }
    }

  }
  raise (SIGTERM);
} /*main*/


//Project biffer.c END -------------------------------
