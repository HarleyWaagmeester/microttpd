#include <sys/time.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdio.h>


fd_set a;


int main () {
  printf("%u\n",FD_SETSIZE);
}
