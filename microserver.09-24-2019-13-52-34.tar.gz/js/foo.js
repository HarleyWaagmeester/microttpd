function handleErrors(response) {
    if (!response.ok) {
        throw Error(response.statusText);
    }
    return response;
}
async function loadHtmlFileIntoDiv(obj) {
    var SRC_REPO = "http://localhost:8080/html/";
    return(
        fetch(SRC_REPO + "ballmove.html")
            .then(resp => handleErrors(resp))
            .then(resp => resp.text())
            .then((data) => {
                obj.innerHTML = data;
                return "ok";
            })
        //        .then(text => console.log("response text = " + text))
            .catch(function(error) {
                console.error("[catch]  " + error);
                return "error";
            }))
};

async function doit() {
    var a;
    //    if (loadHtmlFileIntoDiv(document.getElementById("d1")) === "ok") {
    a = await loadHtmlFileIntoDiv(document.getElementById("d1"));
    if (a === "ok") {
        return "ok";
    }else {
        return "error";
    }
};

function getDocHeight(doc) {
    doc = doc || document;
    // stackoverflow.com/questions/1145850/
    var body = doc.body, html = doc.documentElement;
    var height = Math.max( body.scrollHeight, body.offsetHeight, 
                           html.clientHeight, html.scrollHeight, html.offsetHeight );
    return height;
}
function setIframeHeight(id) {
    var ifrm = document.getElementById(id);
    var doc = ifrm.contentDocument? ifrm.contentDocument: 
        ifrm.contentWindow.document;
    ifrm.style.visibility = 'hidden';
    ifrm.style.height = "10px"; // reset to minimal height ...
    // IE opt. for bing/msn needs a bit added or scrollbar appears
    ifrm.style.height = getDocHeight( doc ) + 4 + "px";
    ifrm.style.visibility = 'visible';
}
setIframeHeight(document.getElementById("d1"));
document.getElementById("d1").innerHTML="ok" ;
alert("foo.js");
