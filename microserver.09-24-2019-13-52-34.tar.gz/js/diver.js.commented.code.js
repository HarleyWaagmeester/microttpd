// Extracted commented code from diver.js





////////////////////////////
// This moves a div for us.
////////////////////////////
/**
 * Drag.js: drag absolutely positioned HTML elements.
 *
 * This module defines a single drag() function that is designed to be called
 * from an onmousedown event handler. Subsequent mousemove events will
 * move the specified element. A mouseup event will terminate the drag.
 * This implementation works with both the standard and IE event models.
 * It requires the getScrollOffsets() function from elsewhere in this book.
 *
 * Arguments:
 *
 * elementToDrag: the element that received the mousedown event or
 * some containing element. It must be absolutely positioned. Its
 *style.left and style.top values will be changed based on the user's
 *drag.
 *
 * event: the Event object for the mousedown event.
 */







//A previous version of the drag paradigm.
// var dragItem = "";
// var container = page;
// var active = false;
// var currentX;
// var currentY;
// var initialX;
// var initialY;
// var xOffset = 0;
// var yOffset = 0;
// var invocation = 0;
// //TAG
// //container.addEventListener("mousedown", dragStart, false);
// container.addEventListener("mouseup", dragEnd, false);
// container.addEventListener("mousemove", drag, false);

// function dragItem_set(obj, e) {
//     dragItem = obj;
// }

// function dragStart(e) {
//     invocation+=1;
//     dragItem = e.target;
//     console.log("*****dragStart*****");
//     console.log("---invocation: "+invocation);
//     console.log("--------dragItem " + dragItem.id);
//     initialX = e.clientX - xOffset;
//     initialY = e.clientY - yOffset;
// //    initialX = e.clientX;
// //    initialY = e.clientY;
//     // if (e.target === dragItem) {
//     //     active = true;
//     // }
// }

// function dragEnd(e) {
//     //console.log("****dragEnd****");
//     //console.log("invocation: "+invocation);
//     initialX = currentX;
//     initialY = currentY;
//     dragItem="expired";
//     //console.log("----dragItem " + dragItem);
// //    active = false;
// }

// function drag(e) {
//     console.log("****possible drag*****");
//     if (e.target === dragItem) {
//         //console.log("---drag");
//         //console.log("----invocation: "+invocation);
//         //console.log("------e.target.id " + e.target.id + "\n" + "------dragItem " + dragItem.id);

//         e.preventDefault();
//         currentX = e.clientX - initialX;
//         currentY = e.clientY - initialY;
//         xOffset = currentX;
//         yOffset = currentY;

//         //console.log("------------e.clientX = " + e.clientX + " e.clientY = " + e.clientY);
//         //console.log("------------initialX = " + initialX + " initialY = " + initialY);
//         //console.log("------------currentX = " + currentX + " currentY = " + currentY);
//        sleep(1000);
//         //console.log("---------calling setTranslate");
//         setTranslate(currentX, currentY, dragItem);
//     }
// }

// function setTranslate(xPos, yPos, obj) {
//     //console.log("*****setTranslate*****");
//     //console.log("invocation: "+invocation);
//     obj.style.transform = "translate3d(" + xPos + "px, " + yPos + "px, 0)";
// }

////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////

///////////////////
// Don't loose this code.
//////////////////

// ondblclick = function(e) {
//     document.getElementById("dive").background-color = "red";
//     //  div1.hidden = 1;
// }

// function createRange(node, chars, range) {
//     if (!range) {
//         range = document.createRange()
//         range.selectNode(node);
//         range.setStart(node, 0);
//     }

//     if (chars.count === 0) {
//         range.setEnd(node, chars.count);
//     } else if (node && chars.count >0) {
//         if (node.nodeType === Node.TEXT_NODE) {
//             if (node.textContent.length < chars.count) {
//                 chars.count -= node.textContent.length;
//             } else {
//                 range.setEnd(node, chars.count);
//                 chars.count = 0;
//             }
//         } else {
//            for (var lp = 0; lp < node.childNodes.length; lp+=1) {
//                 range = createRange(node.childNodes[lp], chars, range);

//                 if (chars.count === 0) {
//                     break;
//                 }
//             }
//         }
//     }

//     return range;
// }
// function setCurrentCursorPosition(chars,id) {
//     if (chars >= 0) {
//         var selection = window.getSelection();

//         range = createRange(document.getElementById(id).parentNode, { count: chars });

//         if (range) {
//             range.collapse(false);
//             selection.removeAllRanges();
//             selection.addRange(range);
//         }
//     }
// }

// <div id="div1" ondrop="drop(event)" ondragover="allowDrop(event)">
//   <img src="img_w3slogo.gif" draggable="true" ondragstart="drag(event)" id="drag1" width="88" height="31">
// </div>

// <div id="div2" ondrop="drop(event)" ondragover="allowDrop(event)"></div>
// // Using drag and drop
// function init() {
//     div_index+=1;
//     page = document.createElement("div");
//     page.id = "page1";
//     page.draggable = "true";
//     page.style.height = "800px";
//     page.style.width = "100%";
//     page.style.border = "solid";
//     page.setAttribute("ondrop","drop(event)" );
//     page.setAttribute("ondragover","allowDrop(event)" );

//     div_50 = document.createElement("div");
//     div_50.className = "div_50";
//     div_50.draggable = "true";
//     div_50.setAttribute ("ondragstart", "drag(event)");
//     div_50.id = "drag1";

//     div_1 = document.createElement("div");
//     div_2 = document.createElement("div");
//     div_3 = document.createElement("div");

//     div_1.innerHTML = "w33 1";
//     div_2.innerHTML = "w33 2";
//     div_3.innerHTML = "w33 3";

//     div_1.className = "w33";
//     div_2.className = "w33";
//     div_3.className = "w33";
//     div_3.draggable = "true";
//     div_3.setAttribute ("ondragstart", "drag(event)");
//     div_3.id = "div3_id";
// //    div_3.style.position = "absolute";

//     div_50.appendChild(div_1);
//     div_50.appendChild(div_2);
//     div_50.appendChild(div_3);

//     page.appendChild(div_50);
//     document.body.appendChild(page);
// }
// // <div id="div1" ondrop="drop(event)" ondragover="allowDrop(event)">
// //   <img src="img_w3slogo.gif" draggable="true" ondragstart="drag(event)" id="drag1" width="88" height="31">
// // </div>

// // <div id="div2" ondrop="drop(event)" ondragover="allowDrop(event)"></div>

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Put this in your html file to use this js code to save the <HTML> node to a blob, and then download it to a file.
// <button id="create">Save the HTML node to a file.</button>
// <a download="pagedesign.html" id="download_html" style="display: none">Download</a>
/////////////////////////////////////////////////////////////////////////////////////////////////////////// ///////////
// function copyHtmlNode() {
// //    var Blob;
//     global_contextDiv.parentNode.removeChild(global_contextDiv);
//     var data = new Blob([document.documentElement.innerHTML], {type: "text/plain"});

//     // If we are replacing a previously generated file we need to
//     // manually revoke the object URL to avoid memory leaks.

//     if (copyHtmlNodeTextFile !== null) {
//         window.URL.revokeObjectURL(copyHtmlNodeTextFile);
//     }

//     copyHtmlNodeTextFile = window.URL.createObjectURL(data);
//     var link = document.getElementById("download_html");
//     link.href = copyHtmlNodeTextFile;
//     link.click();
// }


// var create = document.getElementById("create");
// var textbox = document.getElementById("textbox");

// create.addEventListener("click", function () {
//     var link = document.getElementById("downloadlink");
//     link.href = makeTextFile(document.documentElement.innerHTML);
//     link.click();
//     //        link.style.display = "block";
// }, false);
// document.getElementById("downloadlink").addEventListener("click", function () {
//     document.getElementById("downloadlink").style.display = "none";
// }, false);

// function allowDrop(ev) {
//   ev.preventDefault();
// }

// function drag(ev) {
//   ev.dataTransfer.setData("text", ev.target.id);
// }

// function drop(ev) {
//   ev.preventDefault();
//   var data = ev.dataTransfer.getData("text");
//     console.log(data);
// //    data.style.position = "absolute";
//     ev.target.appendChild(document.getElementById(data));
// }



///////////////////////////////////////////////////////////////////
// Unknown specificity.
//
///////////////////////////////////////////////////////////////////
// function buildClassString( classes ) {
//     if ( classes === null ) {
//         return;
//     }

//     var classString = classes.trim().replace( /(\s{2,})/g, ' ' ).split( ' ' ).join( '.' );

//     return '.' + classString;
// }


// function loadHtmlFileIntoDiv() {
//     var file = prompt("enter file name");
//     fetch('http://localhost:1338/html/' + file)
//         .then(response => response.text())
//         .then((data) => {
//             objForOp.innerHTML = data;
//         })
// }


////////////////////////////////////
// Event listener callbacks.
////////////////////////////////////
// function interceptClick(obj) {
//     console.log("interceptClick");
//     if(global_shift === 1){
//         console.log("disabling onmousemove ..");
//         onmousemove = function (e) {
//             return false;
//         }
//         obj.onmousemove = function (e) {
//             x = e.clientX;
//             y = e.clientY;
//             console.log(x,y);
//             if(y > 200) {
//                 y = 200;
//             }
//             obj.style.top = (y-10)+"px";
//             obj.style.left = (x-10)+"px";
//             if(global_shift === 0){
//                 console.log("enabling onmousemove ..");
//                 onmousemove = function(e) {
//                     x2 = e.clientX;
//                     y2 = e.clientY;
//                     reCalc();
//                     obj.onmousemove = function (e) {
//                         return false;
//                     }
//                 }
//             }
//         }
//     }
// }

