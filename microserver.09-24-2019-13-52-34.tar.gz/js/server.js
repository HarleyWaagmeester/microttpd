// BADASS file.
// Timers that scroll a div to the bottom.

var divScrollToBottom = setInterval (function() {
    var txt = document.getElementById("t1");
    txt.scrollTop = txt.scrollHeight - txt.clientHeight;
}, 3000);
var divClear = setInterval (function() {
    var txt = document.getElementById("t1");
    //                   alert(\"divClear\");
    txt.innerHTML="";
}, 100000);

