
function drag (obj) {
    var dragItem = obj;
    var container = page;

    var active = false;
    var currentX;
    var currentY;
    var initialX;
    var initialY;
    var xOffset = 0;
    var yOffset = 0;
// With a trackpad it takes a double tap to generate a mousedown event.
    container.addEventListener("mousedown", dragStart, false);
    container.addEventListener("mouseup", dragEnd, false);
    container.addEventListener("mousemove", drag, false);
}
function dragStart() {
    initialX = event.clientX - xOffset;
    initialY = event.clientY - yOffset;


    if (event.target === dragItem) {
        active = true;
    }
}

function dragEnd() {
    console.log("dragEnd");
    initialX = currentX;
    initialY = currentY;

    active = false;
}

function drag() {
    if (active) {

        event.preventDefault();

        currentX = event.clientX - initialX;
        currentY = event.clientY - initialY;
    }

    xOffset = currentX;
    yOffset = currentY;

    setTranslate(currentX, currentY, dragItem);
}


function setTranslate(xPos, yPos, el) {
    el.style.transform = "translate3d(" + xPos + "px, " + yPos + "px, 0)";
}
