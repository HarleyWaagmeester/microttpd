// Please be aware that this is alpha code
// This code is maintained with Douglas Crockford's JSLint to achieve consistent style and structure.
// Pressing ctrl and mousedown will allow you to draw a new div.
// Right mouse click on a new div will popup a custom context menu.
// If none of this works, you are invited to create/fix/enable code to accomplish the above stated functionality.
//
// This code is being developed on a laptop computer.
// Mouse behavior on desktop computers needs to be researched.

// This is convienent for the emacs 'occur' fu nction. 
function startOfOutlinePlaceHolder() {
    return false;
}

const HTML_REPO = "http://localhost:8080/html/";
const EXEC_REPO = "http://localhost:8080/exec/";
const SRC_REPO = "http://localhost:8080/src/";

// Global variables are being used in the early development stages of this code.
var div = [];
// index for div array
var div_index = -1;
var global_id = "";
var global_obj = "";
var objForOp = "";
var objToColor = "";
var global_shift = 0;
var page = document.createElement("div");
var global_status_obj = "";
var global_last_obj = "";
var global_contextDiv = "";
var g_iter = 0;
var x1 = 0;
var y1 = 0;
var x2 = 0;
var y2 = 0;
var plot = 0;
var styleStringFile = "";
var htmlStringFile = "";
var javascriptStringFile = "";
var fetchedDataString = "";
// End of global variables.

////////////////////
// Using Floats.
////////////////////
function init() {
    div_index += 1;
    //  Div "page" is the first container.
    page.id = "page1";
    page.style.height = "800px";
    page.style.width = "100%";
    page.style.border = "solid";
    page.addEventListener("contextmenu", interceptContext.bind(null, page), false);

    // var div_50 = document.createElement("div");
    // div_50.className = "div_50";
    // div_50.id = "drag_50_id";

    // var div_1 = document.createElement("div");
    // var div_2 = document.createElement("div");
    // var div_3 = document.createElement("div");

    // var div_a = document.createElement("div");
    // var div_b = document.createElement("div");
    // var div_c = document.createElement("div");

    // div_1.innerHTML = "L";
    // div_2.innerHTML = "L";
    // div_3.innerHTML = "R";

    // // div_a.innerHTML = "L";
    // // div_b.innerHTML = "L";
    // // div_c.innerHTML = "R";

    // div_1.className = "fl20";
    // div_2.className = "fl20";
    // div_3.className = "fr20";
    // div_a.className = "ff5";
    // div_b.className = "ff5";
    // div_c.className = "ff5";
    // div_3.id = "div3_id";
    // //    div_3.style.position = "absolute";

    // div_50.appendChild(div_1);
    // // div_50.appendChild(div_a);
    // // div_50.appendChild(div_b);
    // div_50.appendChild(div_c);

    // div_50.appendChild(div_2);
    // div_50.appendChild(div_3);

    // page.appendChild(div_50);
    document.body.appendChild(page);
}

//////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////

function reCalc() {
    if ( plot === 1) {
        console.log("*****recalc*****");
        var x3 = Math.min(x1,x2);
        var x4 = Math.max(x1,x2);
        var y3 = Math.min(y1,y2);
        var y4 = Math.max(y1,y2);
        div[div_index].style.left = x3 + "px";
        div[div_index].style.top = y3 + "px";
        div[div_index].style.width = x4 - x3 + "px";
        div[div_index].style.height = y4 - y3 + "px";
    }
}


function interceptContext(obj) {
    var contextDiv;
    var contextMenuDiv1;
    var contextMenuDiv2;
    var ev;

    ev = event;
    ev.preventDefault();
    ev.stopPropagation();
    g_iter += 1;
    global_status_obj.innerHTML = g_iter + "<br>context menu<br>object id is " + obj.id + "<br>";
    contextDiv = document.createElement("div");
    global_contextDiv = contextDiv;
    objToColor = obj;
    objForOp = obj;
    console.log(obj);
    contextDiv.style.position = "absolute";
    contextDiv.style.left = ev.clientX + "px";
    contextDiv.style.top = ev.clientY + "px";
    //         contextDiv.style.width = "100px";
    contextDiv.style.height = "100px";
    contextDiv.style.backgroundColor = "white";
    contextDiv.style.border = "solid 1px";
    contextDiv.style.cursor = "pointer";
    contextDiv.style.padding = "5px";
    contextDiv.style.zIndex = "3";
    contextDiv.setAttribute("onmouseleave", "contextDivMouseLeave()");

    contextMenuDiv1 = document.createElement("div");
    contextMenuDiv2 = document.createElement("div");
    contextMenuDiv3 = document.createElement("div");
    contextMenuDiv4 = document.createElement("div");

    contextMenuDiv1.setAttribute("onclick", "picker()");
    contextMenuDiv2.setAttribute("onclick", "copyHtmlNode()");
    contextMenuDiv3.setAttribute("onclick", "devExtractDivAttributesAndStyleIntoFiles()");
    contextMenuDiv4.setAttribute("onclick", "loadHtmlFileIntoDiv()");
//    contextMenuDiv4.addEventListener("onclick", loadHtmlFileIntoDiv.bind(null, obj), false);
//    contextMenuDiv4.addEventListener("onclick", function(){console.log("hi")}, false);

    contextMenuDiv1.innerHTML = "Background Color";
    contextMenuDiv2.innerHTML = "Save Html";
    contextMenuDiv3.innerHTML = "Save Html and CSS";
    contextMenuDiv4.innerHTML = "LoadHtmlFileIntoDiv";

    var picker = document.getElementById("picker");
    picker.setAttribute("onmouseleave", "pickerDivMouseLeave()");

    contextDiv.appendChild(contextMenuDiv1);
    contextDiv.appendChild(contextMenuDiv2);
    contextDiv.appendChild(contextMenuDiv3);
    contextDiv.appendChild(contextMenuDiv4);
    page.appendChild(contextDiv);

    //console.log(obj.id + " " + ev.clientX + " " +  ev.clientY);
    return false;
}

function dragger(elementToDrag, event) {
    // The initial mouse position, converted to document coordinates
    //var scroll = getScrollOffsets(); // A utility function from elsewhere
    var startX = event.clientX;
    var startY = event.clientY;
    // The original position (in document coordinates) of the element
    // that is going to be dragged. Since elementToDrag is absolutely
    // positioned, we assume that its offsetParent is the document body.
    var origX = elementToDrag.offsetLeft;
    var origY = elementToDrag.offsetTop;
    // Compute the distance between the mouse down event and the upper-left
    // corner of the element. We'll maintain this distance as the mouse moves.
    var deltaX = startX - origX;
    var deltaY = startY - origY;
    // Register the event handlers that will respond to the mousemove events
    // and the mouseup event that follow this mousedown event.

    /////////////////////////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////////////////////////
    /**
     * This is the handler that captures mousemove events when an element
     * is being dragged. It is responsible for moving the element.

     **/
    function moveHandler(e) {
        if (!e) {
            e = window.event;
        }

        // IE event Model
        // Move the element to the current mouse position, adjusted by the
        // position of the scrollbars and the offset of the initial click.
        //var scroll = getScrollOffsets();
        //        elementToDrag.style.left = (e.clientX + scroll.x - deltaX) + "px";
        //        elementToDrag.style.top = (e.clientY + scroll.y - deltaY) + "px";
        elementToDrag.style.left = (e.clientX - deltaX) + "px";
        elementToDrag.style.top = (e.clientY - deltaY) + "px";
        // And don't let anyone else see this event.
        if (e.stopPropagation) {
            e.stopPropagation();
        }// Standard
        else {
            e.cancelBubble = true;
        }
        // IE
    }
    /**
     * This is the handler that captures the final mouseup event that
     * occurs at the end of a drag.
     **/
    function upHandler(e) {
        if (!e) {
            e = window.event;
        }// IE Event Model
        // Unregister the capturing event handlers.
        if (document.removeEventListener) { // DOM event model
            document.removeEventListener("mouseup", upHandler, true);
            document.removeEventListener("mousemove", moveHandler, true);
        }
        else if (document.detachEvent) { // IE 5+ Event Model
            elementToDrag.detachEvent("onlosecapture", upHandler);
            elementToDrag.detachEvent("onmouseup", upHandler);
            elementToDrag.detachEvent("onmousemove", moveHandler);
            elementToDrag.releaseCapture();
        }

        // And don't let the event propagate any further.
        if (e.stopPropagation) {
            e.stopPropagation();
        }// Standard model
        else {
            e.cancelBubble = true;
        }
        // IE
    }



    if (document.addEventListener) { // Standard event model
        // Register capturing event handlers on the document
        document.addEventListener("mousemove", moveHandler, true);
        document.addEventListener("mouseup", upHandler, true);
    }


    else if (document.attachEvent) { // IE Event Model for IE5-8
        // In the IE event model, we capture events by calling
        // setCapture() on the element to capture them.
        elementToDrag.setCapture();
        elementToDrag.attachEvent("onmousemove", moveHandler);
        elementToDrag.attachEvent("onmouseup", upHandler);
        // Treat loss of mouse capture as a mouseup event.
        elementToDrag.attachEvent("onlosecapture", upHandler);
    }
    // We've handled this event. Don't let anybody else see it.
    if (event.stopPropagation) {
        event.stopPropagation();
    }// Standard model
    else {
        event.cancelBubble = true;
    }
    // IE
    // Now prevent any default action.
    if (event.preventDefault) {
        event.preventDefault();
    }
    else {
        event.returnValue = false;
    }
    // Standard model
    // IE
}
///////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Put this in your html file to use this js code to put the CSS styleString into a Binary Large OBject, and then download it to a file.
// <a download="pagedesign.css" id="download_css" style="display: none">Download</a>
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function saveStyleStringToFile(styleString) {

    var data = new Blob([styleString], {type: "text/css"});

    // If we are replacing a previously generated file we need to
    // manually revoke the object URL to avoid memory leaks.

    if (styleStringFile !== null) {
        window.URL.revokeObjectURL(styleStringFile);
    }

    styleStringFile = window.URL.createObjectURL(data);
    var link = document.getElementById("download_css");
    link.href = styleStringFile;
    link.click();
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Put this in your html file to use this js code to put the HTML divString into a Binary Large OBject, and then download it to a file.
// <a download="pagedesign.html" id="download_html" style="display: none">Download</a>
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function saveHtmlStringToFile(htmlString) {

    var data = new Blob([htmlString], {type: "text/html"});

    // If we are replacing a previously generated file we need to
    // manually revoke the object URL to avoid memory leaks.

    if (htmlStringFile !== null) {
        window.URL.revokeObjectURL(htmlStringFile);
    }

    htmlStringFile = window.URL.createObjectURL(data);
    var link = document.getElementById("download_html");
    link.href = htmlStringFile;
    link.click();
}
function saveJavascriptStringToFile(javascriptString) {

    var data = new Blob([javascriptString], {type: "text/javascript"});

    // If we are replacing a previously generated file we need to
    // manually revoke the object URL to avoid memory leaks.

    if (javascriptStringFile !== null) {
        window.URL.revokeObjectURL(javascriptStringFile);
    }

    javascriptStringFile = window.URL.createObjectURL(data);
    var link = document.getElementById("download_js");
    link.href = javascriptStringFile;
    link.click();
}

function handleErrors(response) {
    if (!response.ok) {
        throw Error(response.statusText);
    }
    return response;
}
async function loadHtmlFileIntoDiv() {
    //console.log("top load");
//    var file = prompt("enter file name");    
    await runServerFileChooser();    
    return(
        fetch(SRC_REPO + fetchedDataString)
            .then(resp => handleErrors(resp))
            .then(resp => resp.text())
            .then((data) => {
                objForOp.innerHTML = data;
            })
        //        .then(text => console.log("response text = " + text))
            .catch(function(error) {
                console.error("[catch]  " + error);
            }))
}
async function runServerFileChooser() {
    //console.log("top load");
    //    var file = prompt("enter file name");    
    //var output = ;    
    return(
        fetch(EXEC_REPO + "diver_fileChooser.sh")
            .then(resp => handleErrors(resp))
            .then(resp => resp.text())
            .then((data) => {
                fetchedDataString = data;
            })
        //        .then(text => console.log("response text = " + text))
            .catch(function(error) {
                console.error("[catch]  " + error);
            }))
}
function saveTofetchedDataString(data){
    fetchedDataString=data;
//    console.log("-------- saved -------\n" + fetchedDataString);
}
async function loadJavascriptFileIntoString(filename) {
//    console.log("top load");
    return(
        //        fetch('http://localhost:8080/js/' + filename, {mode: 'no-cors'})
//        fetch('http://localhost:8080/js/dragger.js', {mode: 'no-cors'})
    fetch('http://localhost:8080/js/' + filename)
            .then(resp => handleErrors(resp))
            .then(resp => resp.text())
            .then(data => {
//                console.log("---------------\ndata: " + data);
                saveTofetchedDataString(data);
            })
//            .then(resp => function(resp){fetchedDataString=resp.text()})
            .catch(function(error) {
                console.error("[catch]  " + error);
            }))
}


function test(filename) {
    var a = loadJavascriptFileIntoString(filename);
    console.log(a);
}

async function postData(url, data, filename) {
    // Default options are marked with *
    return (fetch(url, {
        method: 'POST', // *GET, POST, PUT, DELETE, etc.
        mode: 'no-cors', // no-cors, cors, *same-origin
        cache: 'no-cache', // *default, no-cache, reload, force-cache, only-if-cached
        credentials: 'same-origin', // include, *same-origin, omit
        headers: {
            'Content-Type': 'html/text',
            //'Content-Type': 'application/x-www-form-urlencoded',
        },
        redirect: 'follow', // manual, *follow, error
        referrer: filename, // no-referrer, *client
        body: data, // body data type must match "Content-Type" header
    }))
//        .then(response => console.log(response));
}
//////////////////////////////////////////////////////////////////////
// Select all div elements. Filter by class, looking for our created divs. Extract the div attributes
// and create and download an html file. Extract the style attribute and create and download a css file.
//////////////////////////////////////////////////////////////////////
async function devExtractDivAttributesAndStyleIntoFiles () {
    //Select all div elements.
    var divs = page.querySelectorAll('div');

    //Use a regex to filter for created divs.
    var regex = /created_by_diver/;

    //Construct an html file while filtering for created divs.
    //Construct a css file while filtering for created divs.
    var i;
    var j;
    var styleString = "";
    var htmlString = "<!DOCTYPE html>\n";
    htmlString += "<html>\n<head>\n";
    htmlString += '<meta charset="UTF-8">\n';
    htmlString += "<link rel='stylesheet' type='text/css' href='/css/pagecreator.css'>\n"
    htmlString += "<link rel='stylesheet' type='text/css' href='/css/pagecreator_base.css'>\n"
    htmlString += "<script src ='/js/pagecreator.js'></script>\n"
    htmlString += "</head>\n";
    htmlString += "<body>\n";
    // We know the attributes we created so we can simply extract them. No need for looping through getAttributeNames.
    for (i=1; i < divs.length; i+=1) {
        if( regex.test(divs[i].getAttribute('class')) === true) {
            console.log(divs[i]);
            htmlString += "<div ";
            htmlString += "id=";
            htmlString += "'" + divs[i].getAttribute("id") + "' ";
            htmlString += "class=";
            htmlString += "'" + divs[i].getAttribute("class") + "' ";
            htmlString += "tabindex=";
            htmlString += "'" + divs[i].getAttribute("tabindex") + "' ";
            htmlString += "contenteditable='false' ";
            htmlString += "spellcheck='false' ";
            htmlString += ">\n";
            htmlString += divs[i].innerHTML;
            htmlString += "\n</div>\n";
            styleString += '#' + divs[i].getAttribute('id') + '{\n ' + divs[i].getAttribute('style').replace(/;/g,";\n") +  '}\n';

//             attributeNames = divs[i].getAttributeNames();
            // htmlString += "<div "
  //          for(j=0; j < attributeNames.length; j+=1) {
            //     n = attributeNames[j];
            //     if (n !== "style") {
            //         if (n == "contenteditable") {
            //             htmlString += "contenteditable='false' ";
            //         }else {
            //         htmlString += n + "=" + "'" + divs[i].getAttribute(n) + "' ";
            //         //                    htmlString += n + "=" + "'" + divs[i].getAttribute(n) + "'" + " \n";
            //         }
            //     }
            // }
            //htmlString += ">\n";
            //htmlString += divs[i].innerHTML;
            //htmlString += "\n</div>\n";
    //        }
            //      styleString += '#' + divs[i].getAttribute('id') + '{\n ' + divs[i].getAttribute('style').replace(/;/g,";\n") +  '}\n';
        }
    }
    htmlString += "\n</body>";
    htmlString += "\n</html>";
//    saveHtmlStringToFile(htmlString);
//    saveStyleStringToFile(styleString);
    fetchedDataString = "";

   // Timestamp versioning is used here during development to ensure that a cached resource file is not used by the browser.
   //  This is implemented by .../mhttpd/makefile-incremental-versioning.mk
    //  Reloading this file in the browser (diver.js, now modified by the makefile) will then make the browser load the newest version
    //  of the timestamped resource. 
    var a = await loadJavascriptFileIntoString("dragger_1566238954.js");

//    console.log("-------------- fds a ----------------\n" + a + "\n----------------------------\n");
//    console.log("-------------- fds ----------------\n" + fetchedDataString + "\n----------------------------\n");
    
//    a=saveJavascriptStringToFile("diver.js");
    await postData("http://localhost:8080/exec/post_cgi.exe", htmlString,"pagecreator.html");
    await postData("http://localhost:8080/exec/post_cgi.exe", styleString,"pagecreator.css");
    await postData("http://localhost:8080/exec/post_cgi.exe", fetchedDataString,"pagecreator.js");
}

// This invokes a process on the server that formats and writes the 'css_code' string into a file.
function server_formatted_write_to_css_file(css_code) {
    var link = document.getElementById("download_html");
    link.href = "http://localhost:1338/formatted_write_to_css_file/" + css_code;
    link.click();
}

///////////////////////////////////////////////////////////////////
// Here we create an absolute positioned div with event listeners.
// Activate with ctrl-double-click, hold the click down, and drag to size the div. (Tested on latop touchpad, desktop is untested.)
///////////////////////////////////////////////////////////////////

var enableMouseDownHandler = 1;  // For debugging. Toggle this manually (0 or 1), in the developer console.
var onmousedown = onMouseDownHandler;
function onMouseDownHandler (e) {
    console.log("onmousedown");
    if(enableMouseDownHandler === 1) {
        event.stopPropagation();
        if (event.ctrlKey) {
            console.log("onmousedown + ctrlKey");
            div_index+=1;
            div[div_index] = document.createElement("div");
            var obj = div[div_index];
            global_obj = obj;
            page.appendChild(obj);
            obj.setAttribute("class", "divs created_by_diver");
            obj.setAttribute("id", "id" + div_index);
            global_id = "id" + div_index;
            global_last_obj = obj;
            if (div_index === 1) {
                var global_status_id = "id" + div_index;
                global_status_obj = obj;
                global_status_obj.style.zIndex = 99;

            }
            obj.setAttribute("contentEditable", "true");
            obj.setAttribute("tabIndex", 1);
            obj.setAttribute("onclick", "focus_this(this)");
            obj.setAttribute("onmouseover", "thisMouseOver(this)");
            //     obj.setAttribute("onmousemove", "thisMouseMove.bind(this)");
            obj.setAttribute("onmouseout", "thisMouseOut(this)");
            //obj.setAttribute("onresize", "alert('resize')");
            //     obj.setAttribute("leftclick", "alert("leftclick")");
            //     obj.setAttribute("leftclick", "alert("leftclick")");
            //     someInput.addEventListener("click", myFunc, false);
            obj.addEventListener("contextmenu", interceptContext.bind(null, obj), false);
            //obj.addEventListener("onresize", function() {alert("resize event");}, false);
            //     obj.addEventListener("dblclick", dragger.bind(null, obj), false);

            //////////////////////// Research this, it appears to be necessary 000
            //     obj.addEventListener("click", dragItem_set.bind(null, obj), false);
            //     obj.addEventListener("click", interceptClick.bind(null, obj), false);

            //     obj.hidden = 0;
            plot = 1;
            x1 = e.clientX;
            y1 = e.clientY;
            //x1 = 0;
            //y1 = 0;
            x2 = 0;
            y2 = 0;
            reCalc();
            return false;
        }

        //console.log("dragStart");
        dragger(event.target,event);
    }
}

/////////////////////
// Event listeners.
/////////////////////
document.addEventListener("keydown", logKeyDown);
document.addEventListener("keyup", logKeyUp);
//document.addEventListener("onmousedown", logMouseDown);
onmousemove = function(e) {
    x2 = e.clientX;
    y2 = e.clientY;
    reCalc();
};
onmouseup = function(e) {
    //console.log(x);
    div[div_index].className = "divs red created_by_diver";
    plot = 0;
};

///////////////////////////////////
// These are useful little tools.
///////////////////////////////////
function logKeyDown(e) {
    //console.log("keydown");
    if(e.shiftKey) {
        //console.log("shift key down");
        global_shift = 1;
    }
    if(e.ctrlKey) {
        //console.log("ctrl key down");
        global_shift = 1;
    }
}
function logKeyUp(e) {
    //console.log("keyup");
    if(e.shiftKey) {
        //console.log("shift key up");
        global_shift = 0;
    }
    if(e.ctrlKey) {
        //console.log("ctrl key up");
        ctrl_shift = 0;
    }
}
function logMouseDown(e) {
    //console.log("logMouseDown");
    //console.log("mouse down event");
    global_mouse_down = 1;
}

function picker () {
    //console.log("picker");
    //console.log(caller);
    pickerdiv = document.getElementById("picker");
    pickerdiv.style.visibility = "visible";
    pickerdiv.style.display = "inline";
    global_contextDiv.parentNode.removeChild(global_contextDiv);
}

// Called by <div id=picker> in diver.html
function colorsAll(color) {
    //console.log(objToColor);
    objToColor.style.backgroundColor = color;
}

function contextDivMouseLeave() {
    //console.log("contextDivMouseLeave");
    global_contextDiv.style.visibility = "hidden";
    global_contextDiv.style.display = "none";
    global_contextDiv.parentNode.removeChild(global_contextDiv);
}
function pickerDivMouseLeave() {
    //console.log("pickerDivMouseLeave");
    pickerDiv = document.getElementById("picker");
    pickerDiv.style.visibility = "hidden";
    pickerDiv.style.display = "none";
}

function thisMouseOut (obj) {
    global_id = "id-none";
    glpbal_last_obj = obj;
    global_status_obj.innerHTML = g_iter + "<br>global_id is " + global_id + "<br>";
}

function thisMouseOver (obj) {
    g_iter+=1;
    global_status_obj.innerHTML = g_iter + "<br>global_id is " + obj.id + "<br>";
    if (obj != global_status_obj) {
        obj.style.zIndex = "2";
        if (global_last_obj != obj) {
            global_last_obj.style.zIndex = "1";
        }
        global_last_obj = obj;
    }
}
// var contextHtml =
//     "<div style = 'position: absolute'>\
//      <a href='javascript:backgroundColor()'>Background Color</a>\
//      <a href='#'>Link 2</a>\
//      <a href='#'>Link 3</a>\
//     </div>";

function focus_this (obj) {
    obj.focus();
}
function sleep(milliseconds) {
    var start = new Date().getTime();
    for (i = 0; i < 1e7; i+=1) {
        if ((new Date().getTime() - start) > milliseconds){
            break;
        }
    }
}
