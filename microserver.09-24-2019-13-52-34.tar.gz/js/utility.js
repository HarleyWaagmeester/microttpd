var images = document.getElementsByTagName("img");
for(var i = 0; i < images.length; i++) {
    var image = images[i];
    image.onclick = function(event) {
	window.location.href = '/html/' + this.id + '.html';
    };
}

var divs = document.getElementsByClassName("menu");
for(var i = 0; i < divs.length; i++) {
    var page = divs[i];
    page.onclick = function(event) {
	window.location.href = '/html/' + this.id + '.html';
    };
}
var items = document.getElementsByClassName("xterm-menu");
for(var i = 0; i < items.length; i++) {
    var page = items[i];
    page.onclick = function(event) {
	window.location.href = '/' + this.id;
    };
}

function setupDate() {
    setInterval("refreshDate();", 1000); // milliseconds
}
function refreshDate() {
    // alert("hi");
    document.getElementById('clock').innerHTML = Date()
}


