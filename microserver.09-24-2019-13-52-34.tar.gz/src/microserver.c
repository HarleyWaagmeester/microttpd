/* Feel free to use this example code in any way
   you see fit (Public Domain) */

#include <sys/types.h>
#ifndef _WIN32
#include <sys/select.h>
#include <sys/socket.h>
#else
#include <winsock2.h>
#endif
#include <microhttpd.h>
#include <time.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <errno.h>
#include <strings.h>
#include <ctype.h>
#include <linux/limits.h>

#define PORT 1337
#define HTML_MIMETYPE "text/html"
#define CSS_MIMETYPE "text/css"
#define JS_MIMETYPE "text/javascript"
#define PNG_MIMETYPE "image/png"
#define MAX_TEXT_SIZE 100000

// Use... blah about global variables 
// This code is not thread safe.
static struct stat sbuf;
static int fd_error_ret;

static int
print_out_key (void *cls, enum MHD_ValueKind kind, 
	       const char *key, const char *value)
{
  printf ("%s: %s\n", key, value);
  return MHD_YES;
}

// This is an exploration into encoding html entities. i.e. convert < to &lt
// This isn't being used for anything at this time.
static char *
encode_html(char* data, char *encoded_data) {
  char *orig_encoded_data;
  unsigned long int p = 0;
  unsigned long int pe = 0;
  
  orig_encoded_data = encoded_data;
  printf("%lu\n",strlen(data));
  printf("data length = %lu\n", (unsigned long int)strlen(data));
  while (p < (unsigned long int)strlen(data)) {
    //  printf("data index = %u, encoded_data index = %u\n", p, pe);
    //    printf("%lu\n",(long unsigned int)data);
    switch(data[p]) {
      /* case '<' : */
      /*   printf("in case <\n"); */
      /*   encoded_data[pe++] = '&'; */
      /*   encoded_data[pe++] = 'l'; */
      /*   encoded_data[pe++] = 't'; */
      /*   encoded_data[pe++] = ';'; */
      /*   ++p; */
      /*   break; */
      /* case '\n' : */
      /*   printf("\nin case newline\n"); */
      /*   encoded_data[pe++] = '<'; */
      /*   encoded_data[pe++] = 'b'; */
      /*   encoded_data[pe++] = 'r'; */
      /*   encoded_data[pe++] = '>'; */
      /*   ++p; */
      /*   break; */
      /* case ' ' : */
      /*   printf("\nin case space\n"); */
      /*   encoded_data[pe++] = '&'; */
      /*   encoded_data[pe++] = 'n';          //search_tag 001 */
      /*   encoded_data[pe++] = 'b'; */
      /*   encoded_data[pe++] = 's'; */
      /*   encoded_data[pe++] = 'p'; */
      /*   encoded_data[pe++] = ';'; */
      /*   ++p; */
      /*   break; */
    default :
      //      putchar('\n');
      encoded_data[pe] = data[p];
      putchar(encoded_data[pe]);
      ++p;
      ++pe;
    }
    
  }
  printf("=============================================================\n");
  printf("orig_encoded_data = %lu, encoded_data = %lu\n", (unsigned long int)orig_encoded_data, (unsigned long int)encoded_data);
  printf("p = %lu, pe = %lu\n", p, pe);
  //  exit(0);
  //  encoded_data[pe] = 0;
  return encoded_data; 
}

// Look for the file or function specified in the url.
// If the file or function isn't found create an error response and set the global variable fd_error_ret to the MHD_queue_response of the error response. 
static int
resolve_url (const char* filename, struct MHD_Connection *connection) {

  struct MHD_Response *response;
  int fd = 0 ;
  unsigned int ret;
  //struct stat sbuf;
  char* pathname;

  pathname = malloc(PATH_MAX);

  // server root directory
  strcpy(pathname, "/home/nsa/GIT/mhttpd");
  strcat(pathname, filename);// TODO: error if length of filename + length of original pathname is greater than  PATH_MAX.
                             // Research Linux limits on the maximum path character length.
  printf("resolve_url:: pathname = %s\n",pathname);
  if ( (-1 == (fd = open (pathname, O_RDONLY))) ||
       (0 != fstat (fd, &sbuf)) )
    {
        
      /* handle error accessing file */
      printf("errno is %s (errno=%d)\n", strerror( errno ), errno );
      if (fd != -1)
      	(void) close (fd);
      const char *errorstr =
        "<html><body>page not found:: subtext: file access error\
                              </body></html>";
      response =
      	MHD_create_response_from_buffer (strlen (errorstr),
      					 (void *) errorstr,
      					 MHD_RESPMEM_PERSISTENT);
      if (NULL != response)
        {
	  printf("error getting file descriptor for: %s\n", pathname);
	  printf("value is %d\n", fd);
	  fd_error_ret =
	    MHD_queue_response (connection, MHD_HTTP_INTERNAL_SERVER_ERROR,
				response);
	  MHD_destroy_response (response);

	  return -1;
        }else {
        return MHD_NO;
      }
    }
  return fd;
}

char* strlwr(const char* s) {
  char* tmp = s;
  
  for (;*tmp;++tmp) {
    *tmp = tolower((unsigned char) *tmp);
  }
  
  return s;
}

int 
create_response (int fd, char* mime_type, struct MHD_Connection *connection) 
{
  struct MHD_Response *response;
  int ret;
  response =
    MHD_create_response_from_fd_at_offset64 (sbuf.st_size, fd, 0);
  MHD_add_response_header (response, "Content-Type", mime_type);
  ret = MHD_queue_response (connection, MHD_HTTP_OK, response);
  MHD_destroy_response (response);
  return ret;
}


static int
answer_to_connection (void *cls, struct MHD_Connection *connection,
                      const char *url_, const char *method,
                      const char *version, const char *upload_data,
                      size_t *upload_data_size, void **con_cls)
{
  struct MHD_Response *response;
  int fd = 0 ;
  int ret;
  char* url;
  //struct stat sbuf;
  FILE *fpipe;
  char data[MAX_TEXT_SIZE]; // This will limit the text size.
  int data_length;
  
  //printf("in answer_to_connection\n");
  printf ("\n\nNew %s request for %s using version %s\n", method, url_, version);
  MHD_get_connection_values (connection, MHD_HEADER_KIND, &print_out_key, NULL);
  if (0 != strcmp (method, "GET"))
    return MHD_NO;

  //////////////////////////////////
  //url == /favicon.ico
  //////////////////////////////////

  url = strlwr(url_);
  if (0 == (strncmp(url,"/favicon.ico",12))) {
    printf("matched /favicon.ico\n");
    fd = resolve_url("/images/favicon.ico",connection);
    printf("fd = %d\n",fd);
    if (-1 == fd) {
      return fd_error_ret;
    }else {
      ret = create_response(fd, PNG_MIMETYPE, connection);
      return ret;
    }
  }

  ///////////////////////////////////
  // url == /images/*
  //////////////////////////////////
  
  if (0 == (strncmp(url,"/images/",8))) {
    printf("matched /images/\n");
    fd = resolve_url(url,connection);
    printf("fd = %d\n",fd);
    if (-1 == fd) {
      return fd_error_ret;
    }else {
      ret = create_response(fd, PNG_MIMETYPE, connection);
      return ret;
    }
  }
  // url == /html/*
  if (0 == (strncmp(url,"/html/",6))) {
    printf("matched /html/\n");
    if (-1 == (fd = resolve_url(url, connection))) {
      printf("fd = %d\n",fd);
      return fd_error_ret;
    }else {
      printf("fd = %d\n",fd);
      ret = create_response(fd, HTML_MIMETYPE, connection);
      return ret;
    }
  }

  /////////////////////////////////////
  // url == /css/*
  /////////////////////////////////////
  
  if (0 == (strncmp(url,"/css/",5))) {
    printf("matched /css/\n");
    if (-1 == (fd = resolve_url(url, connection))) {
      printf("fd = %d\n",fd);
      return fd_error_ret;
    }else {
      printf("fd = %d\n",fd);
      ret = create_response(fd, CSS_MIMETYPE, connection);
      return ret;
    }
  }
  ////////////////////////////////////////
  // url == /js/*
  ////////////////////////////////////////
  
  if (0 == (strncmp(url,"/js/",4))) {
    printf("matched /js/\n");
    if (-1 == (fd = resolve_url(url, connection))) {
      printf("fd = %d\n",fd);
      return fd_error_ret;
    }else {
      printf("fd = %d\n",fd);
      ret = create_response(fd, JS_MIMETYPE, connection);
      return ret;
    }
  }

  ////////////////////////////////////
  // url == /colorpicker-master/*
  /////////////////////////////////////
  
  if (0 == (strncmp(url,"/colorPicker-master/",20))) {
    printf("matched /colorPicker-master/\n");
    if (-1 == (fd = resolve_url(url, connection))) {
      printf("fd = %d\n",fd);
      return fd_error_ret;
    }else {
      printf("fd = %d\n",fd);
      ret = create_response(fd, HTML_MIMETYPE, connection);
      return ret;
    }
  }

  //This is a cludge because subdirectory descent isn't implemented. */
  //////////////////////////////////////
  // url == /colorpicker-master/css
  /////////////////////////////////////
  
  if (0 == (strncmp(url,"/colorPicker-master/css/",24))) {
    printf("matched /colorPicker-master/css/\n");
    if (-1 == (fd = resolve_url(url, connection))) {
      printf("fd = %d\n",fd);
      return fd_error_ret;
    }else {
      printf("fd = %d\n",fd);
      ret = create_response(fd, CSS_MIMETYPE, connection);
      return ret;
    }
  }

  ////////////////////////////////////////////
  // url == /psauxf/*
  ////////////////////////////////////////////
  
  char *command = (char *)"ps auxf";
  char *encoded_data;
  char *data_ptr;

  if (0 == (strncmp(url,"/psauxf",7))) {
    printf("matched /psauxf/\n");

    if ( !(fpipe = (FILE*)popen(command,"r")) )
      {  // If fpipe is NULL
	perror("Problems with pipe");
	exit(1);
      }
    /////////////////// search_tag 001 //////////////////////

    //    strcpy(data, "<html><head></head><body>");
    //    if (MAX_TEXT_SIZE == fread(data+25, MAX_TEXT_SIZE, 1, fpipe)) {
    data_length = fread(data, 1, MAX_TEXT_SIZE-1, fpipe);
    data[data_length+1] = 0;
    if (MAX_TEXT_SIZE-1 == data_length ) {
      printf("In the psauxf handler, MAX_TEXT_SIZE may have been exceeded.\n");
      exit(0);
    }
    pclose(fpipe);
    //    encoded_data = (char *)malloc(strlen (data)*10);
    //    encode_html(data, encoded_data);
    //    exit(0);
    //    response = MHD_create_response_from_buffer (strlen (encoded_data),
    //						(void*) encoded_data, MHD_RESPMEM_MUST_COPY);
    response = MHD_create_response_from_buffer (strlen (data),
						(void*) data, MHD_RESPMEM_MUST_COPY);
    ret = MHD_queue_response (connection, MHD_HTTP_OK, response);
    return ret;
  }

  ////////////////////////////////////////////
  // url == /pstree/*
  ////////////////////////////////////////////
  
  char *pstree_command = (char *)"pstree -acl";
  //  char *encoded_data;
  //char *data_ptr;

  if (0 == (strncmp(url,"/pstree",7))) {
    printf("matched /pstree/\n");

    if ( !(fpipe = (FILE*)popen(pstree_command,"r")) )
      {  // If fpipe is NULL
	perror("Problems with pipe");
	exit(1);
      }
    /////////////////// search_tag 001 //////////////////////

    //    strcpy(data, "<html><head></head><body>");
    //    if (MAX_TEXT_SIZE == fread(data+25, MAX_TEXT_SIZE, 1, fpipe)) {
    data_length = fread(data, 1, MAX_TEXT_SIZE-1, fpipe);
    data[data_length+1] = 0;
    if (MAX_TEXT_SIZE-1 == data_length ) {
      printf("In the pstree handler, MAX_TEXT_SIZE may have been exceeded.\n");
      exit(0);
    }
    pclose(fpipe);
    //    encoded_data = (char *)malloc(strlen (data)*10);
    //    encode_html(data, encoded_data);
    //    exit(0);
    //    response = MHD_create_response_from_buffer (strlen (encoded_data),
    //						(void*) encoded_data, MHD_RESPMEM_MUST_COPY);
    response = MHD_create_response_from_buffer (strlen (data),
						(void*) data, MHD_RESPMEM_MUST_COPY);
    ret = MHD_queue_response (connection, MHD_HTTP_OK, response);
    return ret;
  }

  //////////////////////////////////////
  //url == /xterm-mhttpd
  ///////////////////////////////////////
  
  if (0 == (strncmp(url,"/xterm-mhttpd",13))) {
    //  fd = resolve_url("/html/xterm_png.html", connection);
    //  ret = create_response(fd, HTML_MIMETYPE, connection);

    int pid = fork();
    //    pid = -1;

    if (pid == 0) {
      // This is the child process
      printf("I'm the child process, pid=%d\n", getpid());
    
      // Exec
      char* const argv[] = {"/usr/bin/xterm", "-fn", "9x15", NULL};
      char* const envp[] = {"DISPLAY=:0.0", "HOME=/home/nsa", NULL};
      chdir("/home/nsa/GIT/mhttpd");
      execve("/usr/bin/xterm", argv, envp);
    } else if (pid == -1) {
      printf("fork() failed!");
    } else {
      // This is the parent process
      printf("I'm the parent process, pid=%d\n", getpid());
      //
    }
    // Show a message in the browser.
    const char *page  = "<html><body>\"/usr/bin/xterm\", \"-fn\", \"9x15\"<br></body></html>";
    response = MHD_create_response_from_buffer (strlen (page),
						(void*) page, MHD_RESPMEM_PERSISTENT);
    ret = MHD_queue_response (connection, MHD_HTTP_NOT_FOUND, response);
    return ret;
  }
  
  /////////////////////////////////////
  //url == /xfce4-terminal-in-mhttpd
  /////////////////////////////////////
  
  if (0 == (strncmp(url,"/xfce4-terminal-in-mhttpd",25))) {
    //  fd = resolve_url("/html/xterm_png.html", connection);
    //  ret = create_response(fd, HTML_MIMETYPE, connection);

    int pid = fork();
    //    pid = -1;

    if (pid == 0) {
      // This is the child process
      printf("I'm the child process, pid=%d\n", getpid());
    
      // Exec
      char* const argv[] = {"/usr/bin/xfce4-terminal",\
                            "-e ",\
                            "bash -c 'emacs26 -mm js/diver.js &\
                             bash'",\
                            NULL};
      //char* const argv[] = {"/usr/bin/xfce4-terminal", NULL};
      //      char* const envp[] = {"DISPLAY=:0.0", "HOME=/home/nsa", NULL};
      chdir("/home/nsa/GIT/mhttpd");
      //      execve("/usr/bin/xterm", argv, envp);
      execv("/usr/bin/xfce4-terminal", argv);
    } else if (pid == -1) {
      printf("fork() failed!");
    } else {
      // This is the parent process
      printf("I'm the parent process, pid=%d\n", getpid());
      //
    }
    // Show a message in the browser.
    const char *page  = "<html><body>\"/usr/bin/xfce4-terminal\"<br></body></html>";
    response = MHD_create_response_from_buffer (strlen (page),
						(void*) page, MHD_RESPMEM_PERSISTENT);
    ret = MHD_queue_response (connection, MHD_HTTP_NOT_FOUND, response);
    return ret;
  }

  // no match found
  const char *page  = "<html><body>page not found:: subtext: default error<br></body></html>";
  response = MHD_create_response_from_buffer (strlen (page),
					      (void*) page, MHD_RESPMEM_PERSISTENT);
  ret = MHD_queue_response (connection, MHD_HTTP_NOT_FOUND, response);
  return ret;
}


int
main ()
{
  struct MHD_Daemon *daemon;

  daemon = MHD_start_daemon (MHD_USE_SELECT_INTERNALLY, PORT, NULL, NULL,
			     &answer_to_connection, NULL, MHD_OPTION_END);
  if (NULL == daemon) { 
    printf("error starting microserver daemon\n");
    return 1;
  }
  printf("microserver is running\n");
  (void) getchar ();

  MHD_stop_daemon (daemon);

  return 0;
}

// url == /xterm
/* if (42 == (strncmp(url,"/xterm",1024))) { */
/*   fd = resolve_url("/html/xterm_png.html", connection); */
/*   ret = create_response(fd, HTML_MIMETYPE, connection); */

/*   int pid = fork(); */
/*   //    pid = -1; */

/*   if (pid == 0) { */
/*     // This is the child process */
/*     printf("I'm the child process, pid=%d\n", getpid()); */
    
/*     // Exec */
/*     char* const argv[] = {"/usr/bin/xterm", NULL}; */
/*     char* const envp[] = {"DISPLAY=:0.0", "HOME=/home/nsa", NULL}; */
/*     execve("/usr/bin/xterm", argv, envp); */
/*   } else if (pid == -1) { */
/*     printf("fork() failed!"); */
/*   } else { */
/*     // This is the parent process */
/*     printf("I'm the parent process, pid=%d\n", getpid()); */
/*     //    */




/* static int */
/* get_image (const char *filename, struct MHD_Connection *connection) { */
/*   struct MHD_Response *response; */
/*   int fd = 0 ; */
/*   int ret; */
/*   struct stat sbuf; */

/*   if ( (-1 == (fd = open (filename, O_RDONLY))) || */
/*        (0 != fstat (fd, &sbuf)) ) */
/*     { */
/*       /\* error accessing file *\/ */
/*   if (fd != -1) */
/* 	(void) close (fd); */
/*   const char *errorstr = */
/*     "<html><body>get_image server error has occured!\ */
/*                           </body></html>"; */
/*   response = */
/* 	MHD_create_response_from_buffer (strlen (errorstr), */
/* 					 (void *) errorstr, */
/* 					 MHD_RESPMEM_PERSISTENT); */
/*   if (NULL != response) */
/*     { */
/*       ret = */
/*         MHD_queue_response (connection, MHD_HTTP_INTERNAL_SERVER_ERROR, */
/*                             response); */
/*       MHD_destroy_response (response); */

/*       return ret; */
/*     } */
/*   else */
/*     return MHD_NO; */
/* } */

/*   if (0 == (strncmp(url,"/images/xterm.png",1024))) { */
/*     //    const char *page  = "<html><body>started /usr/bin/xterm<br></body></html>"; */
/*     //response = MHD_create_response_from_buffer (strlen (page), */
/*     //						(void*) page, MHD_RESPMEM_PERSISTENT); */
/*     fd = read_file(url, connection); */
/*     response = */
/*         MHD_create_response_from_fd_at_offset64 (sbuf.st_size, fd, 0); */
/*       MHD_add_response_header (response, "Content-Type", HTML_MIMETYPE); */
/*       ret = MHD_queue_response (connection, MHD_HTTP_OK, response); */
/*       MHD_destroy_response (response); */

/*       return ret; */



/* } // end of get_image */
