convert \
     -size 165x70 \
     xc:lightblue \
     -font Bookman-DemiItalic \
     -pointsize 12 \
     -fill blue \
     -gravity center \
     -draw "text 0,0 '$(cat test.html)'" \
     test.png
