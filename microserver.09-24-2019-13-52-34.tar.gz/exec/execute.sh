#!/bin/bash
# -*- coding: utf-8 -*-

# There is no input sanitizing. The argument list is executed as a shell commandline entry.
# If the executed command doesn't terminate then there will be running and/or defunct processes.
# As an example, if ping is executed there is no way to stop it, other than manually killing the process.

echo "Content-type:text/html"
echo
echo

NAME=execute.sh

#Provide html escape sequences for a few common characters. 
escape () {
    ss="$(echo "${1}"|sed 's/&/\&amp;/g; s/</\&lt;/g; s/>/\&gt;/g; s/"/\&quot;/g; s/'"'"'/\&#39;/g')"
    
}

saveIFS=$IFS
IFS='='
set -- $QUERY_STRING
IFS='+'
set -- $2
IFS=$saveIFS

echo "<html><head>"
echo "<title>$NAME</title>"
echo '<meta name="description" content="'$NAME'">'
echo '<meta name="keywords" content="'$NAME'">'
echo '<meta http-equiv="Content-type" content="text/html;charset=UTF-8">'
echo '<meta content="text/html;charset=UTF-8">'
echo '<meta name="ROBOTS" content="noindex">'
echo '<meta http-equiv="Content-Language" content="en">'
echo "<link rel='stylesheet' type='text/css' href='/exec/css/link_button.css'>"
echo "</head><body style='background-color:tan;'>"
echo "<div style='background-color:powderblue;margin:0px;'>"
echo "<h2>hal clojuresystems utility execute result</h2>"
echo "<pre><code>"
date
uname -a
echo "</code></pre></div>"
echo "<div style='background-color:grey;margin:0px;'>"
echo "<pre><code>"
#echo $QUERY_STRING
#echo $@
set -- $(echo $@ | sed 's/%7C/\|/g;')
bash -c "$*"

# #escape "${c}"
# #echo "${ss}"
echo "</code></pre></div>"
echo "<div>"
echo '<a class="link_button" href="/html/hal_homepage.html">return</a>'
echo "</div></body></html>"
