#!/bin/bash
zOpenPath="$(zenity --file-selection)"
if [ "$zOpenPath" != "" ]
then
vi $zOpenPath
fi
