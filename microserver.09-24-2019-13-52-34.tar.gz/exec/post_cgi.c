 /* This reads post data and uses the base name of HTTP_REFERER as the filename to write the data to. */
 /* Ignore the following comment. */
 /* The data is run through sed to unescape some things. */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <syslog.h>
#include <linux/limits.h>

extern char **environ;

void print_empty_html_page();

// Use this to get the filename from the end of the HTTP_REFERER header entry.
char*
basename (const char *filename)
{
  char *p = strrchr (filename, '/');
  return p ? p + 1 : (char *) filename;
}

// Use this to get the extension of a filename.
char*
extension (const char *filename)
{
  char *p = strrchr (filename, '.');
  return p ? p + 1 : (char *) filename;
}

int main(int argc, char* argv[]) {

  /* for (char **env = environ; *env != 0; env++) */
  /*   { */
  /*     char *thisEnv = *env; */
  /*     syslog(LOG_CRIT,"%s", thisEnv); */
  /*   } */
  char pathname[PATH_MAX]; 
  char * req_method_str = getenv("REQUEST_METHOD");
  char * filename = getenv("HTTP_REFERER");
  //  char command [1024];
  
  if (req_method_str != NULL) {
    if (strcmp(req_method_str, "POST") == 0) {
      // process POST arguments
      syslog(LOG_CRIT,"%s: %s", argv[0], "matched 'POST'");
      char * len_str = getenv("CONTENT_LENGTH");

      if (len_str != NULL) {
        int len = atoi(len_str);
        syslog(LOG_CRIT,"%d", len);

        if (len > 0) {
          FILE * fp;
          //          fp = fopen("tmp.txt", "w");

          if(0 == strcmp(extension(filename), "js")){
            strcpy(pathname,"/home/nsa/GIT/mhttpd/js/");
            strcat(pathname,basename(filename));
            fp = fopen(pathname, "w");
            
          }
          if(0 == strcmp(extension(filename), "css")){
            strcpy(pathname,"/home/nsa/GIT/mhttpd/css/");
            strcat(pathname,basename(filename));
            fp = fopen(pathname, "w");
            
          }
          if(0 == strcmp(extension(filename), "html")){
            strcpy(pathname,"/home/nsa/GIT/mhttpd/html/");
            strcat(pathname,basename(filename));
            fp = fopen(pathname, "w");
            
          }

          //          fp = fopen(basename(filename), "w");

          char * postdata = malloc((len + 1) * sizeof(char));
          fread(postdata, sizeof(char), len, stdin);
          postdata[len] = '\0';
          fprintf(fp, "%s\n", postdata);

          free(postdata);
          fclose(fp);
        }
        /* sprintf(command,"sed -e '/Content/d' -e '/[-][-][*][*][*][*][*]/d' -e '/^[s]*$/d' -e '/WebKitFormBoundary/d' -e '/Submit/d' < tmp.txt > %s",basename(filename)); */
        /* system(command); */
        /* system("rm tmp.txt"); */
      }
    }
  }
  print_empty_html_page();

  return 0;
}


void print_empty_html_page() {

    // Send the content type, letting the browser know this is HTML
    printf("Content-type:  text/html\r\n\r\n");
    // Header information that prevents browser from caching
    printf(
            "<META HTTP-EQUIV=\"CACHE-CONTROL\" CONTENT=\"NO-CACHE, NO-STORE\">\r\n\r\n");
    // Top of the page
    printf("<html>\n");
    printf("<BODY>\n");

    // Finish up the page
    printf("</BODY></html>\n");
}
