//http://www.youtube.com/user/thecplusplusguy
//Thanks for the typed in code to Tapit85
#include <gtk-3.0/gtk/gtk.h>
#include <syslog.h>
//#include <cstring>
// ---------------  NOTES ----------------------------------------------------------

/* Solution */
/*   Go to end of buffer with GtkTextbuffer::get_end_iter(). */
/*   Insert the text with GtkTextbuffer::insert(). */
/*   Scroll to the end of text with GtkTextview::scroll_to_mark(). */

/* #define MAX_TEXT_SIZE 0x100000 */

/* int main(int argc, char* argv[]) */
/* { */
/*   gtk_init(&argc, &argv); */

/*   GtkWidget* window = gtk_window_new(GTK_WINDOW_TOPLEVEL); */
/*   GtkWidget* view      = gtk_text_view_new(); */
/*   GtkTextBuffer* buffer = gtk_text_view_get_buffer(GTK_TEXT_VIEW(view)); */
/*   GtkTextIter end; */

/*   gtk_text_buffer_get_end_iter(buffer, &end); */
/*   gtk_text_buffer_insert(buffer, &end, "Hello ubuntuforums", -1); */
/*   gtk_container_add(GTK_CONTAINER(window), view); */
/*   gtk_widget_show_all(window); */

/*   gtk_main(); */

/*   return 0; */
/* } */
// ------------------------------------------------------------------------------------

#define MAX_TEXT_SIZE 0x100000
extern char **environ;

struct objects_structure {
  GtkWidget* window;
  GtkWidget* text_view;
  char* command;
  char* message;
};

static int
emacsclient26 () {
  //  char* const args[] = {"runEmacsclient26.bin", "-c ", "-n ", "/home/nsa/GIT/mhttpd/makefile", NULL};
  char*  args[] = {"runEmacsclient26.bin", "/home/nsa/GIT/mhttpd/exec/menu.c ", "-c ", "-n ", NULL};
  //      char* const envp[] = {"DISPLAY=:0.0", "HOME=/home/nsa", NULL};
  //  chdir("/home/nsa");
  printf("%s\n",args[1]);
  execve("/home/nsa/bin/runEmacsclient26.bin", args, environ);
  return 0;
}

static int
shell_command (GtkMenuItem* menu_item, objects_structure* objects) {

  FILE *fpipe;
  int data_length;
  char data[MAX_TEXT_SIZE]; // This will truncate very large responses. Dynamic buffer allocation isn't implemented.
  GtkTextBuffer* buffer = gtk_text_view_get_buffer(GTK_TEXT_VIEW(objects->text_view));
  GtkTextIter start;
  GtkTextIter end;
  char command [1024];
  
  gtk_text_buffer_get_start_iter (buffer,&start);
  gtk_text_buffer_get_end_iter (buffer,&end);
  gtk_text_buffer_delete (buffer,&start,&end);  
  
  if ( 0 == strcmp("ls -l", gtk_menu_item_get_label (menu_item))) {
    strcpy(command,"ls -l");
  }
  if ( 0 == strcmp("ps auxf", gtk_menu_item_get_label (menu_item))) {
    strcpy(command,"ps auxf");
  }
  if ( 0 == strcmp("env", gtk_menu_item_get_label (menu_item))) {
    strcpy(command,"env");
  }
  
  //  gtk_container_add(GTK_CONTAINER(window), view);
  
  if ( !(fpipe = (FILE*)popen(command,"r")) )
    //if ( !(fpipe = (FILE*)popen("ping 10.0.1.1","r")) )
    {  // If fpipe is NULL
      syslog(LOG_CRIT,"%s","Problem with pipe");
      perror("Problems with pipe");
      exit(1);
    }
  
  while ( 0 != (data_length = fread(data, 1, 1, fpipe) ) ) {
    data[data_length+1] = 0;
     //  if (MAX_TEXT_SIZE-1 == data_length ) {
    //    exit(0);
    //    gtk_widget_show_all(window);
    //    printf("%s",data);
    gtk_text_buffer_get_end_iter(buffer, &end);
    gtk_text_buffer_insert(buffer, &end, data, -1);
  }

  pclose(fpipe);
  return 1;
}

// Function to open a dialog box with a message
void
quick_message (GtkWidget* menu_item, objects_structure* objects)
{
 GtkWidget *dialog, *label, *content_area;
 GtkDialogFlags flags;

 // Create the widgets
 flags = GTK_DIALOG_DESTROY_WITH_PARENT;
 dialog = gtk_dialog_new_with_buttons ("About",
                                       GTK_WINDOW(objects->window),
                                       flags,
                                       "OK",
                                       GTK_RESPONSE_NONE,
                                       NULL);
 content_area = gtk_dialog_get_content_area (GTK_DIALOG (dialog));
 label = gtk_label_new (objects->message);

 // Ensure that the dialog box is destroyed when the user responds

 g_signal_connect_swapped (dialog,
                           "response",
                           G_CALLBACK (gtk_widget_destroy),
                           dialog);

 // Add the label, and show everything we’ve added
 gtk_window_set_default_size (GTK_WINDOW(dialog), 100, 100);
        
 gtk_container_add (GTK_CONTAINER (content_area), label);
 gtk_widget_show_all (dialog);
}

static void menu_response(GtkWidget* menu_item, gpointer data)
{
        if(strcmp(gtk_menu_item_get_label(GTK_MENU_ITEM(menu_item)), "New") == 0)       // equal
        {
                g_print("You pressed New\n");
        }
        if(strcmp(gtk_menu_item_get_label(GTK_MENU_ITEM(menu_item)), "Exit") == 0)      // equal
        {
          gtk_main_quit();
        }
        /* if(strcmp(gtk_menu_item_get_label(GTK_MENU_ITEM(menu_item)), "About") == 0)     // equal */
        /* { */
        /*   //                g_print("You pressed About\n"); */
        /*   quick_message (objects->window, "menu by hal"); */
        /* } */
}

int main(int argc, char* argv[]) {
        gtk_init(&argc, &argv);

        
        objects_structure* objects = (objects_structure*)malloc (sizeof (objects_structure));
        GtkWidget *window, *view, *scrolled_window, *menu_bar, *menu_item, *file_menu, *help_menu, *vbox, *button;
        
        view = gtk_text_view_new();
        window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
        gtk_window_set_keep_above (GTK_WINDOW(window), TRUE);
        gtk_window_set_title (GTK_WINDOW(window),
                              "badass menu");
         objects->window=window;
        objects->text_view=view;
        gtk_text_view_set_monospace (GTK_TEXT_VIEW(objects->text_view),
                                     TRUE);
        g_signal_connect(window, "delete-event", G_CALLBACK(gtk_main_quit), NULL);
        gtk_window_set_default_size (GTK_WINDOW(window), 300, 300);
        
        scrolled_window = gtk_scrolled_window_new (NULL, NULL);
        gtk_scrolled_window_set_policy (GTK_SCROLLED_WINDOW (scrolled_window), 
                                        GTK_POLICY_AUTOMATIC, 
                                        GTK_POLICY_AUTOMATIC);
        /* gtk_widget_set_hexpand (scrolled_window, GTK_ALIGN_FILL); */
        /* gtk_widget_set_vexpand (scrolled_window, GTK_ALIGN_FILL); */
        //        gtk_widget_set_size_request (scrolled_window,
        //                             300,
        //                             180);
        
        menu_bar = gtk_menu_bar_new();

        file_menu = gtk_menu_new();
        
        help_menu = gtk_menu_new();

        menu_item = gtk_menu_item_new_with_label("File");
        gtk_menu_item_set_submenu(GTK_MENU_ITEM(menu_item), file_menu);
        gtk_menu_shell_append(GTK_MENU_SHELL(menu_bar), menu_item);

        menu_item = gtk_menu_item_new_with_label("Help");
        gtk_menu_item_set_submenu(GTK_MENU_ITEM(menu_item), help_menu);
        gtk_menu_shell_append(GTK_MENU_SHELL(menu_bar), menu_item);

        menu_item = gtk_menu_item_new_with_label("ls -l");
        gtk_menu_shell_append(GTK_MENU_SHELL(file_menu), menu_item);
        g_signal_connect(menu_item, "activate", G_CALLBACK(shell_command), objects);

        menu_item = gtk_menu_item_new_with_label("ps auxf");
        gtk_menu_shell_append(GTK_MENU_SHELL(file_menu), menu_item);
        g_signal_connect(menu_item, "activate", G_CALLBACK(shell_command), objects);

        menu_item = gtk_menu_item_new_with_label("env");
        gtk_menu_shell_append(GTK_MENU_SHELL(file_menu), menu_item);
        g_signal_connect(menu_item, "activate", G_CALLBACK(shell_command), objects);

        menu_item = gtk_menu_item_new_with_label("emacsclient");
        gtk_menu_shell_append(GTK_MENU_SHELL(file_menu), menu_item);
        g_signal_connect(menu_item, "activate", G_CALLBACK(emacsclient26), objects);

        menu_item = gtk_menu_item_new_with_label("Exit");
        gtk_menu_shell_append(GTK_MENU_SHELL(file_menu), menu_item);
        g_signal_connect(menu_item, "activate", G_CALLBACK(menu_response), NULL);

        menu_item = gtk_menu_item_new_with_label("About");
        gtk_menu_shell_append(GTK_MENU_SHELL(help_menu), menu_item);
        objects->message = "menu by hal";
        g_signal_connect(menu_item, "activate", G_CALLBACK(quick_message), objects);

        gtk_container_add (GTK_CONTAINER (scrolled_window), 
                           view);
        vbox = gtk_box_new(GTK_ORIENTATION_VERTICAL, 0);
        button = gtk_button_new_with_label("version alpha.001");
        gtk_box_pack_start(GTK_BOX(vbox), menu_bar,0,0,0);
        gtk_box_pack_start(GTK_BOX(vbox), button,0,0,0);
        gtk_box_pack_start(GTK_BOX(vbox), scrolled_window,TRUE,TRUE,0);

        gtk_container_add(GTK_CONTAINER(window), vbox);

        gtk_widget_show_all(window);
        gtk_main();
        return 0;
}
