#!/bin/bash
echo "Content-type:text/html"
echo
echo
echo "<html><head>"
echo "<title>$NAME</title>"
echo '<meta name="description" content="'$NAME'">'
echo '<meta name="keywords" content="'$NAME'">'
echo '<meta http-equiv="Content-type" content="text/html;charset=UTF-8">'
echo '<meta name="ROBOTS" content="noindex">'
echo "<link rel='stylesheet' type='text/css' href='/exec/css/link_button.css'>"
echo "</head><body><pre><code>"
export DISPLAY=:0.0
export HOME=/home/nsa
./runMenubin.bin
echo "<div>"
echo "BADASS operation status report<br>"
echo "pathname: /home/nsa/GIT/mhttpd/exec/menu.bin.sh <br>"
echo "version 001b<br>"
echo '<a class="link_button" href="/html/hal_homepage.html">return to hal</a>'
echo "</div></code></pre></body></html>"
