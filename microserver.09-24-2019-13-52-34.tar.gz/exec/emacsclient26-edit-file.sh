#!/bin/bash
echo "Content-type:text/html"
echo
echo
echo "<html><head>"
echo "<title>$NAME</title>"
echo '<meta name="description" content="'$NAME'">'
echo '<meta name="keywords" content="'$NAME'">'
echo '<meta http-equiv="Content-type" content="text/html;charset=UTF-8">'
echo '<meta name="ROBOTS" content="noindex">'
echo "<link rel='stylesheet' type='text/css' href='/exec/css/link_button.css'>"
echo "</head><body><pre><code>"
export DISPLAY=:0.0
export HOME=/home/nsa
zOpenPath="$(./filechooser.bin)"
if [ "$zOpenPath" != "" ]
then
    /home/nsa/GIT/mhttpd/exec/runEmacsclient26.bin $zOpenPath&
else
    echo ""file selection failed<br>""
fi
echo "<div>"
echo "BADASS operation status report<br>"
echo "pathname: /home/nsa/GIT/mhttpd/exec/emacsclient26-edit-file.sh <br>"
echo "version 001<br>"
echo '<a class="link_button" href="/html/hal_homepage.html">return to hal</a>'
echo "</div></code></pre></body></html>"
