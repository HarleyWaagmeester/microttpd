
 /* NOTES: Need to use syslog to document the exit status of emacsclient26. */

#include <syslog.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>

#define _GNU_SOURCE

#define VERSION ".001"
#define UNIT "/usr/bin/emacsclient26"
#define PROGNAME "runEmacsclient26.bin"

extern char **environ;
//////////////////////////////////////
// fork emacs, in the child close stdin, stdout, it would be more robust to loop through /proc and close all file descriptors
///////////////////////////////////////


int
main(int argc, char* argv[]) {
  char* filename;
  
  //  printf("Content-type:text/html\n\n");
  if (! (argc > 1)) {
    printf("usage: %s filename<br>\n",argv[0]);
    exit (1);
  }

  filename = malloc(strlen (argv[1]));
  
  strncpy(filename, argv[1],strlen(argv[1]));
  printf("<!-- The below html was created by %s  -->",PROGNAME);
  printf("<div style=background:wheat;>");
  printf("version %s<br>\nrunning emacsclient26 -c %s<br>\n",VERSION, filename);
  printf("</div>");

  
  
  int pid = fork();
    //    pid = -1;

    if (pid == 0) {
      // This is the child process
      //printf("I'm the child process, pid=%d\n", getpid());
      // Exec
      /*       printf("%s\n",filename); */
      /* for (char **env = environ; *env != 0; env++) */
      /*   { */
      /*     char *thisEnv = *env; */
      /*     printf("%s\n", thisEnv); */
      /*   } */
      close(1);
      close(2);
      char* const args[] = {UNIT, "-c", "-n", filename, NULL};
      //      char* const envp[] = {"DISPLAY=:0.0", "HOME=/home/nsa", NULL};
      chdir("/home/nsa");
      execve(UNIT, args, environ);
    } else if (pid == -1) {
      printf("fork() failed!");
    }
}
