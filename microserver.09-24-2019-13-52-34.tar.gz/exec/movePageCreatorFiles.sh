#!/bin/bash
# -*- coding: utf-8 -*-

# There is no input sanitizing. The argument list is executed as a shell commandline entry.
# If the executed command doesn't terminate then there will be running and/or defunct processes.
# As an example, if ping is executed there is no way to stop it other than manually killing the process.
NAME=`"movePageCreatorFiles.sh"`
escape () {
    ss="$(echo "${1}"|sed 's/&/\&amp;/g; s/</\&lt;/g; s/>/\&gt;/g; s/"/\&quot;/g; s/'"'"'/\&#39;/g')"
    
}
echo "Content-type:text/html"
echo
echo
echo "<html><head>"
echo "<title>$NAME</title>"
echo '<meta name="description" content="'$NAME'">'
echo '<meta name="keywords" content="'$NAME'">'
echo '<meta http-equiv="Content-type" content="text/html;charset=UTF-8">'
echo '<meta name="ROBOTS" content="noindex">'
echo '<meta http-equiv="Content-Language" content="en">'
echo "<link rel='stylesheet' type='text/css' href='/exec/css/link_button.css'>"
echo "</head><body><pre><code>"
echo "<h2>hal clojuresystems utility script result</h2>"
escape "$(mv /home/nsa/Downloads/pagecreator.html /home/nsa/GIT/mhttpd/html/ 2>&1)"
echo $ss
escape "$(mv /home/nsa/Downloads/pagecreator.css /home/nsa/GIT/mhttpd/css/ 2>&1)"
echo $ss
escape "$(mv /home/nsa/Downloads/pagecreator.js /home/nsa/GIT/mhttpd/js/ 2>&1)"
echo $ss
escape "$(rm /home/nsa/Downloads/pagecreator* 2>&1)"
echo $ss
echo "<br>"
echo '<a class="link_button" href="/html/hal_homepage.html">return</a>'
#si="$(ps auxf)"
#escape "${si}"
#echo "${ss}"
#printf %s $si
echo "</code></pre></body></html>"
exit

