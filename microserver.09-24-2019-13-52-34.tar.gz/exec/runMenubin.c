/* Fork a process */

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <errno.h>

int
main() {

  int pid = fork();
  //    pid = -1;

  if (pid == 0) {
    // This is the child process
    //printf("I'm the child process, pid=%d\n", getpid());
    
    // Exec
    /* char* const argv[] = {"/home/nsa/GIT/mhttpd/exec/menu.bin",\ */
    /*                       "-e ",\ */
    /*                       "bash -c 'emacs26 -mm js/diver.js &\ */
    /*                        bash'",\ */
    /*                       NULL}; */
    //char* const argv[] = {"/usr/bin/xfce4-terminal", NULL};
    //      char* const envp[] = {"DISPLAY=:0.0", "HOME=/home/nsa", NULL};
    close(1);
    close(2);
    chdir("/home/nsa/GIT/mhttpd/exec");
    char* const argv[] = {NULL};
    //      execve("/usr/bin/xterm", argv, envp);
    execv("/home/nsa/GIT/mhttpd/exec/menu.bin", argv);
  } else if (pid == -1) {
    //printf("fork() failed!");
  } else {
    // This is the parent process
    //printf("I'm the parent process, pid=%d\n", getpid());
    //
  }
}
