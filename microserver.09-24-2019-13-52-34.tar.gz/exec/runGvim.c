#include <syslog.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <unistd.h>

#define _GNU_SOURCE
extern char **environ;
//////////////////////////////////////
// fork gvim, in the child close stdin, stdout, it would be more robust to loop through /proc and close all file desriptors
///////////////////////////////////////


int
main(int argc, char* argv[]) {
  char* filename;
  
  //  printf("Content-type:text/html\n\n");
  if (argc != 2) {
    printf("usage: %s filename<br>\n",argv[0]);
    exit (1);
  }

  filename = malloc(strlen (argv[1]));
  
  strncpy(filename, argv[1],strlen(argv[1]));
  printf("running gvim %s<br>\n",filename);

  
  
  int pid = fork();
    //    pid = -1;

    if (pid == 0) {
      // This is the child process
      //printf("I'm the child process, pid=%d\n", getpid());
      // Exec
      //      printf("%s\n",filename);
      /* for (char **env = environ; *env != 0; env++) */
      /*   { */
      /*     char *thisEnv = *env; */
      /*     printf("%s\n", thisEnv);     */
      /*   } */
      close(1);
      close(2);
      char* const args[] = {"runGvim.exe", filename, NULL};
      //      char* const envp[] = {"DISPLAY=:0.0", "HOME=/home/nsa", NULL};
      chdir("/home/nsa");
      execve("/usr/bin/gvim", args, environ);
    } else if (pid == -1) {
      printf("fork() failed!");
    } else {
      // This is the parent process
      //printf("I'm the parent process, pid=%d\n", getpid());
      //
      exit(0);
    }
}
