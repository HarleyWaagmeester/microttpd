#include <sys/types.h>
#include <sys/wait.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <syslog.h>

#define READER 0
#define WRITER 1
#define MAX_TEXT_SIZE 8096

int
header() {
  printf( "Content-type:text/html\r\n\r\n");
  printf("<html><head>");
  printf("<title>$NAME</title>");
  printf( "'<meta name=\"description\" content=\"'$NAME'\">");
  printf( "'<meta name=\"keywords\" content=\"'$NAME'\">");
  printf( "'<meta http-equiv=\"Content-type\" content=\"text/html;charset=UTF-8\">");
  printf( "'<meta content=\"text/html;charset=UTF-8\">");
  printf( "'<meta name=\"ROBOTS\" content=\"noindex\">");
  printf( "'<meta http-equiv=\"Content-Language\" content=\"en\">");
  printf( "\"<link rel='stylesheet' type='text/css' href='/exec/css/link_button.css'>\"");
  printf( "\"</head><body style='background-color:tan;'>\"");
  printf( "\"<div style='background-color:powderblue;margin:0px;'>\"");
  printf( "\"<h2>hal clojuresystems utility execute result</h2>\"");
  printf( "\"<pre><code>\"");
  printf( "\"</code></pre></div>\"");
  printf( "\"<div style='background-color:grey;margin:0px;'>\"");
  printf( "\"<pre><code>\"");
  return 0;
}
    

int
main(int argc, char *argv[])
{
  FILE* fpipe;
  int pipefd[2];
  pid_t cpid;
  int len;
  int i = 0;
  
  char buf[MAX_TEXT_SIZE];
  char buf2[MAX_TEXT_SIZE];
  char rbuf[1024];
  /* if (argc != 2) { */
  /*   fprintf(stderr, "Usage: %s <string>\n", argv[0]); */
  /*   exit(EXIT_FAILURE); */
  /* } */
  header();
  if (pipe(pipefd) == -1) {
    perror("pipe");
    exit(EXIT_FAILURE);
  }

  cpid = fork();
  if (cpid == -1) {
    perror("fork");
    exit(EXIT_FAILURE);
  }

  if (cpid == 0) {    /* Child writes from pipe */
    close(0);
    close(1);
    close(pipefd[READER]);          /* Close unused read end */

        if ( !(fpipe = (FILE*)popen("ping hal","r")) )
    //        if ( !(fpipe = (FILE*)popen("netstat -ctn","r")) )
      {  // If fpipe is NULL
        syslog(LOG_CRIT,"%s","Problem with pipe");
        perror("Problems with pipe");
        exit(1);
      }

    /* while (NULL != fgets(buf, MAX_TEXT_SIZE, fpipe)) { */
    /*   write(pipefd[WRITER], &buf, strlen(buf)); */
    /*   buf[0]=0; */
    /*   //      printf("::%lu\n", strlen(buf)); */
    /* } */

        //TODO:
        //popen or ping seems to be outputting incorrect text
        //netstat -ctn looks ok
        
    
    while(0 != (len = fread(buf,1,1,fpipe))) {
      //printf("_%d_",buf[0]);
      if(buf[0] != 10) {
        buf2[i++] = buf[0];
      }else {
      buf2[i++]=10;
      buf2[i++]=0;
      write(pipefd[WRITER], &buf2, strlen(buf2));
      i=0;
      //buf[len]=0;
      }
    }
    pclose(fpipe);
    close(pipefd[WRITER]);          /* Reader will see EOF */
    _exit(EXIT_SUCCESS);

  } else {            /* Parent reads from pipe */
    close(pipefd[WRITER]);          /* Close unused write end */
    while (0!= read(pipefd[0], rbuf, 1024)) {
      printf("%s",rbuf);
    }
    wait(NULL);                /* Wait for child */
    exit(EXIT_SUCCESS);
  }
}

