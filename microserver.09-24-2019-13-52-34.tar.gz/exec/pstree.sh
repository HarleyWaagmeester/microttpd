#!/bin/sh
# -*- coding: utf-8 -*-
NAME=`"pstree"`
EXE=pstree
escape () {
    ss="$(echo "${1}"|sed 's/&/\&amp;/g; s/</\&lt;/g; s/>/\&gt;/g; s/"/\&quot;/g; s/'"'"'/\&#39;/g')"
    
}
echo "Content-type:text/html"
echo
echo
echo "<html><head>"
echo "<title>$NAME</title>"
echo '<meta name="description" content="'$NAME'">'
echo '<meta name="keywords" content="'$NAME'">'
echo '<meta http-equiv="Content-type" content="text/html;charset=UTF-8">'
echo '<meta name="ROBOTS" content="noindex">'
echo "<link rel='stylesheet' type='text/css' href='/exec/css/link_button.css'>"
echo "</head><body><pre><code>"
date
echo $0
uname -a
si= "${EXE}"
escape "${si}"
echo "${ss}"
echo "<div>"
echo '<a class="link_button" href="/html/hal_homepage.html">return</a>'
echo "</div></code></pre></body></html>"
